const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const root = __dirname;
require('dotenv').config({ path: path.join(root, '.env') });

const express = require('express');
const Database = require('better-sqlite3');

const app = express();
const port = Number(process.env.PORT || 3000);
const host = process.env.HOST || '0.0.0.0';
const databaseDirectory = path.join(root, 'database');
const configuredDatabasePath = process.env.HOSTEL_DATABASE_PATH || path.join(databaseDirectory, 'hostel.sqlite');
const databasePath = path.isAbsolute(configuredDatabasePath)
  ? configuredDatabasePath
  : path.resolve(root, configuredDatabasePath);
fs.mkdirSync(path.dirname(databasePath), { recursive: true });
const database = new Database(databasePath);
const authSecret = process.env.AUTH_SECRET || crypto.randomBytes(32).toString('hex');
const staffModules = new Set([
  'dashboard', 'students', 'rooms', 'hostels', 'fees', 'warnings', 'complaints',
  'leave', 'attendance', 'notices', 'mess', 'facilities', 'reports', 'activity',
  'committees', 'stock', 'applications', 'notifications'
]);

database.pragma('foreign_keys = ON');
database.exec(fs.readFileSync(path.join(databaseDirectory, 'schema.sql'), 'utf8'));
const userColumns = database.pragma('table_info(users)');
if (!userColumns.some((column) => column.name === 'student_id')) {
  database.exec('ALTER TABLE users ADD COLUMN student_id INTEGER REFERENCES students(id) ON DELETE CASCADE');
}
const studentColumns = database.pragma('table_info(students)');
if (!studentColumns.some((column) => column.name === 'email')) {
  database.exec("ALTER TABLE students ADD COLUMN email TEXT NOT NULL DEFAULT ''");
}
const refreshedUserColumns = database.pragma('table_info(users)');
if (!refreshedUserColumns.some((column) => column.name === 'must_change_password')) {
  database.exec('ALTER TABLE users ADD COLUMN must_change_password INTEGER NOT NULL DEFAULT 0');
}
database.exec(`
  CREATE UNIQUE INDEX IF NOT EXISTS idx_users_student_id ON users(student_id) WHERE student_id IS NOT NULL;
  CREATE UNIQUE INDEX IF NOT EXISTS idx_students_email ON students(email COLLATE NOCASE) WHERE email <> '';
`);
database.prepare("UPDATE users SET must_change_password = 0 WHERE role = 'student'").run();
database.exec(fs.readFileSync(path.join(databaseDirectory, 'seed.sql'), 'utf8'));

app.use(express.json({ limit: '1mb' }));
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, PATCH, OPTIONS');
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});
app.use(express.static(root, { index: 'smart_hostel_management_frontend_v2.html' }));

function logActivity(action, module, metadata = {}) {
  database.prepare(
    'INSERT INTO activity_logs (action, module, metadata) VALUES (?, ?, ?)'
  ).run(action, module, JSON.stringify(metadata));
}

function requirePasswordRotation(req, res, next) {
  if (req.user.role !== 'student' && req.user.must_change_password && req.path !== '/auth/change-password') {
    return res.status(403).json({ message: 'Change your temporary password before using the student portal' });
  }
  next();
}

function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `scrypt:${salt}:${hash}`;
}

function verifyPassword(password, storedPassword) {
  if (storedPassword.startsWith('demo:')) return storedPassword === `demo:${password}`;
  const [, salt, storedHash] = storedPassword.split(':');
  if (!salt || !storedHash) return false;
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return storedHash.length === hash.length && crypto.timingSafeEqual(
    Buffer.from(storedHash, 'hex'),
    Buffer.from(hash, 'hex')
  );
}

function parsePermissions(value) {
  try {
    const permissions = JSON.parse(value || '[]');
    return Array.isArray(permissions) ? permissions.filter((module) => staffModules.has(module)) : [];
  } catch (error) {
    return [];
  }
}

function createAuthToken(user) {
  const payload = Buffer.from(JSON.stringify({ id: user.id, expiresAt: Date.now() + 8 * 60 * 60 * 1000 })).toString('base64url');
  const signature = crypto.createHmac('sha256', authSecret).update(payload).digest('base64url');
  return `${payload}.${signature}`;
}

function authenticate(req, res, next) {
  const token = req.headers.authorization?.replace(/^Bearer\s+/i, '');
  const [payload, signature] = (token || '').split('.');
  if (!payload || !signature) return res.status(401).json({ message: 'Authentication required' });
  const expected = crypto.createHmac('sha256', authSecret).update(payload).digest();
  const supplied = Buffer.from(signature, 'base64url');
  if (supplied.length !== expected.length || !crypto.timingSafeEqual(supplied, expected)) {
    return res.status(401).json({ message: 'Invalid or expired login session' });
  }
  let tokenData;
  try {
    tokenData = JSON.parse(Buffer.from(payload, 'base64url').toString());
  } catch (error) {
    return res.status(401).json({ message: 'Invalid or expired login session' });
  }
  if (!Number.isInteger(tokenData.id) || tokenData.expiresAt <= Date.now()) {
    return res.status(401).json({ message: 'Invalid or expired login session' });
  }
  const user = database.prepare(`
    SELECT id, username, email, full_name, role, role_title, permissions_json, student_id,
           must_change_password
    FROM users WHERE id = ? AND is_active = 1
  `).get(tokenData.id);
  if (!user) return res.status(401).json({ message: 'Account is inactive or no longer exists' });
  if (user.role === 'student' && !user.student_id) {
    return res.status(403).json({ message: 'Student account is not linked to a student record' });
  }
  user.permissions = parsePermissions(user.permissions_json);
  delete user.permissions_json;
  user.must_change_password = Boolean(user.must_change_password);
  req.user = user;
  next();
}

function canAccessModule(user, module) {
  return user.role !== 'student' && (user.role === 'admin' || user.role === 'warden' || user.permissions.includes(module));
}

function requireModule(module) {
  return (req, res, next) => {
    if (!canAccessModule(req.user, module)) return res.status(403).json({ message: `Permission required: ${module}` });
    next();
  };
}

function requireAccountManager(req, res, next) {
  if (req.user.role !== 'admin' && req.user.role !== 'warden') {
    return res.status(403).json({ message: 'Only an admin or warden can manage staff logins' });
  }
  next();
}

function requireAdministrator(req, res, next) {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ message: 'Administrator access is required' });
  }
  next();
}

function getState(user) {
  const students = database.prepare(`
    SELECT s.id, s.full_name AS name, s.father_name AS father, s.department AS dept, s.email,
           COALESCE(r.room_number, 'Unassigned') AS room, s.phone, s.status
    FROM students s
    LEFT JOIN rooms r ON r.id = s.room_id
    ORDER BY s.id
  `).all();
  const rooms = database.prepare(`
    SELECT room_number, capacity, occupied_beds
    FROM rooms WHERE status = 'Active' ORDER BY room_number
  `).all().map((room) => [room.room_number, room.capacity, room.occupied_beds]);
  const warnings = database.prepare(`
    SELECT student_name AS student, room_number AS room, application_count AS count,
           violation_type AS type, application_date AS date, status
    FROM warning_applications
    WHERE id IN (SELECT MAX(id) FROM warning_applications GROUP BY student_name)
    ORDER BY id
  `).all();
  const records = database.prepare(`
    SELECT id, module, payload, created_at AS createdAt, updated_at AS updatedAt
    FROM app_records ORDER BY id DESC
  `).all().map((record) => ({
    ...record,
    payload: JSON.parse(record.payload || '{}')
  }));
  if (!user) return { students, rooms, warnings, records };
  return {
    students: canAccessModule(user, 'students') ? students : [],
    rooms: canAccessModule(user, 'rooms') ? rooms : [],
    warnings: canAccessModule(user, 'warnings') ? warnings : [],
    records: records.filter((record) => canAccessModule(user, record.module))
  };
}

app.get('/api/health', (req, res) => {
  res.json({ ok: true, service: 'smart-hostel-api', timestamp: new Date().toISOString() });
});

app.post('/api/auth/student/signup', (req, res) => {
  const fullName = String(req.body?.fullName || '').trim();
  const fatherName = String(req.body?.fatherName || '').trim();
  const department = String(req.body?.department || '').trim();
  const email = String(req.body?.email || '').trim().toLowerCase();
  const phone = String(req.body?.phone || '').trim();
  const username = String(req.body?.username || '').trim().toLowerCase();
  const password = String(req.body?.password || '');
  if (!fullName || !department || !email || !username || !password) {
    return res.status(400).json({ message: 'Name, department, email, username and password are required' });
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return res.status(400).json({ message: 'Enter a valid email address' });
  }
  if (!/^[a-z0-9._-]{3,32}$/.test(username)) {
    return res.status(400).json({ message: 'Username must be 3-32 characters and use letters, numbers, dots, underscores or hyphens' });
  }
  if (password.length < 8 || !/[A-Z]/.test(password) || !/[a-z]/.test(password) || !/\d/.test(password)) {
    return res.status(400).json({ message: 'Password must be at least 8 characters and include uppercase, lowercase and a number' });
  }
  try {
    const createStudentAccount = database.transaction(() => {
      const studentResult = database.prepare(`
        INSERT INTO students (full_name, father_name, department, email, phone, status)
        VALUES (?, ?, ?, ?, ?, 'Inactive')
      `).run(fullName, fatherName, department, email, phone);
      const studentId = Number(studentResult.lastInsertRowid);
      const userResult = database.prepare(`
        INSERT INTO users (username, email, password_hash, full_name, role, role_title, student_id, is_active)
        VALUES (?, ?, ?, ?, 'student', 'Student', ?, 0)
      `).run(username, email, hashPassword(password), fullName, studentId);
      return { studentId, userId: Number(userResult.lastInsertRowid) };
    });
    const created = createStudentAccount();
    logActivity('Student signup awaiting approval', 'Students', {
      studentId: created.studentId,
      userId: created.userId
    });
    return res.status(201).json({
      message: 'Account created. Sign-in will be available after an administrator activates it.'
    });
  } catch (error) {
    if (error.code === 'SQLITE_CONSTRAINT_UNIQUE') {
      return res.status(409).json({ message: 'That email or username is already registered' });
    }
    throw error;
  }
});

app.post('/api/auth/student/password-request', (req, res) => {
  const fullName = String(req.body?.fullName || '').trim();
  const department = String(req.body?.department || '').trim();
  const roomNumber = String(req.body?.roomNumber || '').trim();
  if (!fullName || !department || !roomNumber) {
    return res.status(400).json({ message: 'Full name, department and room number are required' });
  }
  if (fullName.length > 120 || department.length > 100 || roomNumber.length > 30) {
    return res.status(400).json({ message: 'One or more fields exceed the allowed length' });
  }
  const room = database.prepare(`
    SELECT id FROM rooms WHERE room_number = ? AND status = 'Active'
    ORDER BY hostel_id LIMIT 1
  `).get(roomNumber);
  if (!room) return res.status(400).json({ message: 'Enter a valid active hostel room number' });

  const createRequest = database.transaction(() => {
    const studentResult = database.prepare(`
      INSERT INTO students (full_name, department, room_id, status)
      VALUES (?, ?, ?, 'Inactive')
    `).run(fullName, department, room.id);
    const studentId = Number(studentResult.lastInsertRowid);
    const username = `student${studentId}`;
    database.prepare(`
      INSERT INTO users (username, password_hash, full_name, role, role_title, student_id, must_change_password, is_active)
      VALUES (?, ?, ?, 'student', 'Student', ?, 1, 0)
    `).run(username, hashPassword(crypto.randomBytes(32).toString('hex')), fullName, studentId);
    database.prepare('INSERT INTO student_account_requests (student_id) VALUES (?)').run(studentId);
    return { studentId, username };
  });
  const request = createRequest();
  logActivity('Student password requested', 'Students', {
    studentId: request.studentId,
    fullName,
    department,
    roomNumber
  });
  res.status(201).json({
    message: 'Password request sent to the hostel administrator.',
    studentId: request.studentId,
    username: request.username
  });
});

app.post('/api/auth/login', (req, res) => {
  const { username, password } = req.body || {};
  const candidate = database.prepare(`
    SELECT id, username, email, full_name, role, role_title, permissions_json, student_id,
           must_change_password, is_active, password_hash FROM users
    WHERE username = ? OR email = ?
  `).get(username, username);
  if (!candidate || !verifyPassword(password || '', candidate.password_hash)) {
    return res.status(401).json({ message: 'Invalid username or password' });
  }
  if (!candidate.is_active) {
    return res.status(403).json({ message: 'Your account is awaiting administrator activation or has been deactivated' });
  }
  if (candidate.role === 'student' && !candidate.student_id) {
    return res.status(403).json({ message: 'Student account is not linked to a student record' });
  }
  if (candidate.password_hash.startsWith('demo:')) {
    database.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(hashPassword(password), candidate.id);
  }
  delete candidate.password_hash;
  candidate.permissions = parsePermissions(candidate.permissions_json);
  delete candidate.permissions_json;
  candidate.must_change_password = Boolean(candidate.must_change_password);
  logActivity('User logged in', 'Authentication', { userId: candidate.id });
  res.json({ user: candidate, token: createAuthToken(candidate) });
});

app.post('/api/auth/student/register', authenticate, (req, res) => {
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({ message: 'Only an administrator can create student accounts' });
  }
  if (req.user.must_change_password) {
    return res.status(403).json({ message: 'Change your temporary password before creating accounts' });
  }
  const studentId = Number(req.body?.studentId);
  const username = String(req.body?.username || '').trim().toLowerCase();
  const password = String(req.body?.password || '');
  if (!Number.isInteger(studentId) || studentId < 1 || !username || !password) {
    return res.status(400).json({ message: 'Student ID, username and password are required' });
  }
  if (!/^[a-z0-9._-]{3,32}$/.test(username)) {
    return res.status(400).json({ message: 'Username must be 3-32 characters and use letters, numbers, dots, underscores or hyphens' });
  }
  if (password.length < 8 || !/[A-Z]/.test(password) || !/[a-z]/.test(password) || !/\d/.test(password)) {
    return res.status(400).json({ message: 'Password must be at least 8 characters and include uppercase, lowercase and a number' });
  }
  const student = database.prepare(`
    SELECT id, full_name, email FROM students
    WHERE id = ? AND status = 'Active'
  `).get(studentId);
  if (!student) return res.status(404).json({ message: 'Active student record not found' });
  const email = String(student.email || '').trim().toLowerCase();
  if (!email) return res.status(400).json({ message: 'Add a student email to the student record before creating a login' });
  if (database.prepare('SELECT id FROM users WHERE student_id = ?').get(student.id)) {
    return res.status(409).json({ message: 'A student account already exists. Sign in with its username or contact the hostel office.' });
  }
  try {
    const result = database.prepare(`
      INSERT INTO users (username, email, password_hash, full_name, role, role_title, student_id, must_change_password)
      VALUES (?, ?, ?, ?, 'student', 'Student', ?, 0)
    `).run(username, email, hashPassword(password), student.full_name, student.id);
    const user = {
      id: Number(result.lastInsertRowid), username, email, full_name: student.full_name,
      role: 'student', role_title: 'Student', student_id: student.id,
      must_change_password: false, permissions: []
    };
    logActivity('Student account created', 'Authentication', { userId: user.id, studentId: student.id });
    return res.status(201).json({ user: { id: user.id, username: user.username, full_name: user.full_name, email: user.email, student_id: user.student_id } });
  } catch (error) {
    if (error.code === 'SQLITE_CONSTRAINT_UNIQUE') {
      return res.status(409).json({ message: 'That username or email is already in use' });
    }
    throw error;
  }
});

app.use('/api', authenticate);
app.use('/api', requirePasswordRotation);

app.post('/api/student/applications', (req, res) => {
  if (req.user.role !== 'student' || !req.user.student_id) {
    return res.status(403).json({ message: 'Student portal access is required' });
  }
  const applicationType = String(req.body?.applicationType || '').trim();
  const details = String(req.body?.details || '').trim();
  const allowedTypes = new Set(['Leave', 'Room Change', 'Maintenance', 'General Request']);
  if (!allowedTypes.has(applicationType) || !details) {
    return res.status(400).json({ message: 'Choose an application type and provide the request details' });
  }
  const startDate = String(req.body?.startDate || '').trim();
  const endDate = String(req.body?.endDate || '').trim();
  if (applicationType === 'Leave') {
    const validDate = (value) => {
      if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
      const parsed = new Date(`${value}T00:00:00Z`);
      return !Number.isNaN(parsed.getTime()) && parsed.toISOString().slice(0, 10) === value;
    };
    if (!validDate(startDate) || !validDate(endDate) || startDate > endDate) {
      return res.status(400).json({ message: 'Enter valid leave dates with the end date on or after the start date' });
    }
  }
  const requestedRoom = String(req.body?.requestedRoom || '').trim();
  if (applicationType === 'Room Change' && !requestedRoom) {
    return res.status(400).json({ message: 'Enter the room you are requesting' });
  }
  const student = database.prepare(
    "SELECT full_name FROM students WHERE id = ? AND status = 'Active'"
  ).get(req.user.student_id);
  if (!student) return res.status(403).json({ message: 'Student profile is inactive or unavailable' });

  const payload = {
    studentId: req.user.student_id,
    student: student.full_name,
    applicationType,
    details,
    status: 'Pending',
    ...(applicationType === 'Leave' ? { startDate, endDate } : {}),
    ...(applicationType === 'Room Change' ? { requestedRoom } : {})
  };
  const result = database.prepare(
    "INSERT INTO app_records (module, payload) VALUES ('applications', ?)"
  ).run(JSON.stringify(payload));
  logActivity('Student application submitted', 'Applications', {
    studentId: req.user.student_id,
    applicationId: result.lastInsertRowid
  });
  res.status(201).json({
    application: {
      id: Number(result.lastInsertRowid),
      type: applicationType,
      details,
      status: 'Pending',
      submittedAt: new Date().toISOString()
    }
  });
});

app.get('/api/student/portal', (req, res) => {
  if (req.user.role !== 'student' || !req.user.student_id) {
    return res.status(403).json({ message: 'Student portal access is required' });
  }
  const student = database.prepare(`
    SELECT s.id, s.full_name AS name, s.department, s.semester, s.status,
           COALESCE(r.room_number, 'Unassigned') AS room
    FROM students s LEFT JOIN rooms r ON r.id = s.room_id
    WHERE s.id = ? AND s.status = 'Active'
  `).get(req.user.student_id);
  if (!student) return res.status(403).json({ message: 'Student profile is inactive or unavailable' });

  const rooms = database.prepare(`
    SELECT h.name AS hostel, r.room_number AS room, r.floor, r.capacity,
           r.occupied_beds AS occupiedBeds, r.capacity - r.occupied_beds AS availableBeds
    FROM rooms r JOIN hostels h ON h.id = r.hostel_id
    WHERE r.status = 'Active' ORDER BY h.name, r.floor, r.room_number
  `).all();
  const fees = database.prepare(`
    SELECT id, description, amount, paid_amount AS paidAmount,
           amount - paid_amount AS balance, due_date AS dueDate,
           status, receipt_number AS receiptNumber
    FROM fee_records WHERE student_id = ? ORDER BY due_date DESC, id DESC
  `).all(student.id);
  const applications = database.prepare(`
    SELECT id, payload, created_at AS submittedAt
    FROM app_records
    WHERE module = 'applications'
    ORDER BY id DESC
  `).all().flatMap((record) => {
    const payload = JSON.parse(record.payload || '{}');
    if (Number(payload.studentId) !== student.id) return [];
    return [{
      id: record.id,
      type: String(payload.applicationType || 'Application'),
      details: String(payload.details || ''),
      status: String(payload.status || 'Pending'),
      submittedAt: record.submittedAt
    }];
  });
  const savedFeePayments = database.prepare(`
    SELECT id, payload FROM app_records WHERE module = 'fees' ORDER BY id DESC LIMIT 100
  `).all().flatMap((record) => {
    try {
      const payload = JSON.parse(record.payload || '{}');
      const linkedId = Number(payload.studentId || payload.student_id || 0);
      const linkedName = String(payload.student || payload.studentName || '').trim().toLowerCase();
      if (linkedId !== student.id && (!linkedName || linkedName !== student.name.trim().toLowerCase())) return [];
      const amount = Number(String(payload.amount || '').replace(/[^\d.-]/g, ''));
      if (!Number.isFinite(amount) || amount <= 0) return [];
      return [{
        id: `record-${record.id}`,
        description: `${payload.month || payload.description || 'Fee'} payment`,
        amount,
        paidAmount: amount,
        balance: 0,
        dueDate: '',
        status: 'PAID',
        receiptNumber: ''
      }];
    } catch (error) {
      return [];
    }
  });
  fees.push(...savedFeePayments);
  const attendance = database.prepare(`
    SELECT attendance_date AS date, status
    FROM attendance_records WHERE student_id = ?
    ORDER BY attendance_date DESC LIMIT 60
  `).all(student.id);
  const leaveRequests = database.prepare(`
    SELECT leave_type AS leaveType, start_date AS startDate, end_date AS endDate,
           reason, status, created_at AS submittedAt
    FROM leave_requests WHERE student_id = ? ORDER BY created_at DESC LIMIT 50
  `).all(student.id);
  const attendanceSummary = database.prepare(`
    SELECT COUNT(*) AS totalDays,
           COALESCE(SUM(status = 'Present'), 0) AS presentDays,
           COALESCE(SUM(status = 'Absent'), 0) AS absentDays
    FROM attendance_records WHERE student_id = ?
  `).get(student.id);
  const occupancy = database.prepare(`
    SELECT COALESCE(SUM(capacity), 0) AS totalBeds,
           COALESCE(SUM(occupied_beds), 0) AS occupiedBeds,
           COALESCE(SUM(capacity - occupied_beds), 0) AS availableBeds
    FROM rooms WHERE status = 'Active'
  `).get();

  const notices = database.prepare(`
    SELECT title, body, category, created_at AS publishedAt
    FROM notices ORDER BY created_at DESC LIMIT 20
  `).all();
  const savedNotices = database.prepare(`
    SELECT payload, created_at AS publishedAt FROM app_records WHERE module = 'notices'
    ORDER BY id DESC LIMIT 20
  `).all().flatMap((record) => {
    try {
      const payload = JSON.parse(record.payload || '{}');
      const audience = String(payload.audience || '').trim().toLowerCase();
      const isForStudent = !audience || ['all', 'all students', 'students', 'public'].includes(audience) ||
        (audience === 'specific student' && (String(payload.studentId || '') === String(student.id) || payload.student === student.name));
      const title = payload.title || payload.noticeTitle || payload.subject || payload.action;
      const body = payload.body || payload.content || payload.noticeContent || payload.message;
      return isForStudent && title && body ? [{ title, body, category: payload.category || 'Notice', publishedAt: record.publishedAt }] : [];
    } catch (error) {
      return [];
    }
  });
  const messMenu = database.prepare(`
    SELECT menu_date AS date, breakfast, lunch, dinner, announcement
    FROM mess_menu ORDER BY menu_date DESC LIMIT 14
  `).all();
  const savedMenus = database.prepare(`
    SELECT payload, created_at AS publishedAt FROM app_records WHERE module = 'mess'
    ORDER BY id DESC LIMIT 20
  `).all().flatMap((record) => {
    try {
      return [{ ...JSON.parse(record.payload || '{}'), publishedAt: record.publishedAt }];
    } catch (error) {
      return [];
    }
  });

  res.json({
    student,
    rooms,
    fees,
    attendance,
    leaveRequests,
    applications,
    reports: { occupancy, attendance: attendanceSummary },
    notices: [...savedNotices, ...notices].slice(0, 30),
    messMenu: [...savedMenus, ...messMenu].slice(0, 30)
  });
});

app.get('/api/users', requireAccountManager, (req, res) => {
  const users = database.prepare(`
    SELECT id, username, email, full_name, role, role_title, permissions_json, is_active, created_at
    FROM users WHERE role IN ('warden', 'staff') ORDER BY id DESC
  `).all().map((user) => ({
    id: user.id,
    username: user.username,
    email: user.email,
    full_name: user.full_name,
    role: user.role,
    role_title: user.role_title,
    permissions: parsePermissions(user.permissions_json),
    is_active: Boolean(user.is_active),
    created_at: user.created_at
  }));
  res.json({ users });
});

app.get('/api/student-accounts', requireAdministrator, (req, res) => {
  const accounts = database.prepare(`
    SELECT s.id AS studentId, u.username, u.is_active AS isActive,
           u.must_change_password AS mustChangePassword, s.full_name AS name,
           s.father_name AS father, s.department AS dept, s.email, s.phone,
           COALESCE(r.room_number, 'Unassigned') AS room, s.status,
           requests.created_at AS requestCreatedAt,
           requests.password_issued_at AS passwordIssuedAt
    FROM users u JOIN students s ON s.id = u.student_id
    LEFT JOIN rooms r ON r.id = s.room_id
    LEFT JOIN student_account_requests requests ON requests.student_id = s.id
    WHERE u.role = 'student' ORDER BY u.is_active, s.id DESC
  `).all().map((account) => ({
    ...account,
    isActive: Boolean(account.isActive),
    mustChangePassword: Boolean(account.mustChangePassword),
    passwordPending: Boolean(account.requestCreatedAt && !account.passwordIssuedAt)
  }));
  res.json({ accounts });
});

app.patch('/api/student-accounts/:studentId/password', requireAdministrator, (req, res) => {
  const studentId = Number(req.params.studentId);
  const password = String(req.body?.password || '');
  if (!Number.isInteger(studentId) || studentId < 1) {
    return res.status(400).json({ message: 'A valid student ID is required' });
  }
  if (password.length < 8 || !/[A-Z]/.test(password) || !/[a-z]/.test(password) || !/\d/.test(password)) {
    return res.status(400).json({ message: 'Password must be at least 8 characters and include uppercase, lowercase and a number' });
  }
  const account = database.prepare(`
    SELECT u.id AS userId, u.username, s.status AS studentStatus
    FROM users u JOIN students s ON s.id = u.student_id
    JOIN student_account_requests requests ON requests.student_id = s.id
    WHERE s.id = ? AND u.role = 'student' AND requests.password_issued_at IS NULL
  `).get(studentId);
  if (!account) return res.status(404).json({ message: 'Pending student password request not found' });
  if (account.studentStatus === 'Graduated') {
    return res.status(409).json({ message: 'Graduated student accounts cannot be activated' });
  }
  const issuePassword = database.transaction(() => {
    const requestUpdate = database.prepare(`
      UPDATE student_account_requests SET password_issued_at = CURRENT_TIMESTAMP
      WHERE student_id = ? AND password_issued_at IS NULL
    `).run(studentId);
    if (!requestUpdate.changes) return false;
    database.prepare(`
      UPDATE users SET password_hash = ?, must_change_password = 0, is_active = 1
      WHERE id = ?
    `).run(hashPassword(password), account.userId);
    database.prepare(`
      UPDATE students SET status = 'Active', updated_at = CURRENT_TIMESTAMP WHERE id = ?
    `).run(studentId);
    return true;
  });
  if (!issuePassword()) {
    return res.status(409).json({ message: 'This student password request has already been handled' });
  }
  logActivity('Student temporary password issued', 'Students', {
    studentId,
    changedBy: req.user.id
  });
  res.json({ ok: true, username: account.username, isActive: true, mustChangePassword: false });
});

app.patch('/api/student-accounts/:studentId/status', requireAdministrator, (req, res) => {
  const studentId = Number(req.params.studentId);
  const { isActive } = req.body || {};
  if (!Number.isInteger(studentId) || studentId < 1 || typeof isActive !== 'boolean') {
    return res.status(400).json({ message: 'A valid student ID and account status are required' });
  }
  const account = database.prepare(`
    SELECT u.id AS userId, s.status AS studentStatus
    FROM users u JOIN students s ON s.id = u.student_id
    WHERE s.id = ? AND u.role = 'student'
  `).get(studentId);
  if (!account) return res.status(404).json({ message: 'Student account not found' });
  if (isActive && account.studentStatus === 'Graduated') {
    return res.status(409).json({ message: 'Graduated student accounts cannot be activated' });
  }
  const updateStatus = database.transaction(() => {
    database.prepare('UPDATE users SET is_active = ? WHERE id = ?').run(Number(isActive), account.userId);
    database.prepare('UPDATE students SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?')
      .run(isActive ? 'Active' : 'Inactive', studentId);
  });
  updateStatus();
  logActivity(isActive ? 'Student account activated' : 'Student account deactivated', 'Students', {
    studentId,
    changedBy: req.user.id
  });
  res.json({ ok: true, isActive });
});

app.post('/api/users', requireAdministrator, (req, res) => {
  const { username, email = '', fullName, roleTitle, password, permissions = [], role = 'staff' } = req.body || {};
  const normalizedUsername = String(username || '').trim().toLowerCase();
  const normalizedEmail = String(email || '').trim().toLowerCase();
  const normalizedName = String(fullName || '').trim();
  const normalizedTitle = String(roleTitle || '').trim();
  if (normalizedUsername.length < 3 || !/^[a-z0-9._-]+$/.test(normalizedUsername)) {
    return res.status(400).json({ message: 'Username must be at least 3 characters and use only letters, numbers, dots, underscores or hyphens' });
  }
  if (!normalizedName || !normalizedTitle || !password) {
    return res.status(400).json({ message: 'Full name, role title and password are required' });
  }
  if (password.length < 8 || !/[A-Z]/.test(password) || !/[a-z]/.test(password) || !/\d/.test(password)) {
    return res.status(400).json({ message: 'Password must be at least 8 characters and include uppercase, lowercase and a number' });
  }
  if (!Array.isArray(permissions) || permissions.some((module) => !staffModules.has(module))) {
    return res.status(400).json({ message: 'Choose valid module permissions' });
  }
  if (req.user.role === 'warden' && role !== 'staff') {
    return res.status(403).json({ message: 'Wardens can create staff logins only' });
  }
  if (!['staff', 'warden'].includes(role)) {
    return res.status(400).json({ message: 'Account role must be staff or warden' });
  }
  try {
    const result = database.prepare(`
      INSERT INTO users (username, email, password_hash, full_name, role, role_title, permissions_json, must_change_password)
      VALUES (?, ?, ?, ?, ?, ?, ?, 1)
    `).run(normalizedUsername, normalizedEmail || null, hashPassword(password), normalizedName, role, normalizedTitle, JSON.stringify([...new Set(permissions)]));
    logActivity('Staff login created', 'Staff', { userId: result.lastInsertRowid, createdBy: req.user.id });
    res.status(201).json({ ok: true, id: result.lastInsertRowid });
  } catch (error) {
    if (error.code === 'SQLITE_CONSTRAINT_UNIQUE') return res.status(409).json({ message: 'Username or email is already in use' });
    throw error;
  }
});

app.post('/api/auth/change-password', (req, res) => {
  const { userId, currentPassword, newPassword } = req.body || {};
  if (!Number.isInteger(Number(userId)) || Number(userId) !== req.user.id || !currentPassword || !newPassword) {
    return res.status(400).json({ message: 'User, current password and new password are required' });
  }
  if (newPassword.length < 8 || !/[A-Z]/.test(newPassword) || !/[a-z]/.test(newPassword) || !/\d/.test(newPassword)) {
    return res.status(400).json({ message: 'New password must be at least 8 characters and include uppercase, lowercase and a number' });
  }
  if (currentPassword === newPassword) {
    return res.status(400).json({ message: 'New password must be different from the current password' });
  }
  const user = database.prepare(
    'SELECT id, password_hash FROM users WHERE id = ? AND is_active = 1'
  ).get(Number(userId));
  if (!user || !verifyPassword(currentPassword, user.password_hash)) {
    return res.status(401).json({ message: 'Current password is incorrect' });
  }
  database.prepare('UPDATE users SET password_hash = ?, must_change_password = 0 WHERE id = ?')
    .run(hashPassword(newPassword), user.id);
  logActivity('Password changed', 'Authentication', { userId: user.id });
  res.json({ ok: true, message: 'Password changed successfully' });
});

app.get('/api/state', (req, res) => res.json(getState(req.user)));

app.get('/api/records/:module', (req, res) => {
  if (!canAccessModule(req.user, req.params.module)) return res.status(403).json({ message: `Permission required: ${req.params.module}` });
  const records = database.prepare(`
    SELECT id, module, payload, created_at AS createdAt, updated_at AS updatedAt
    FROM app_records WHERE module = ? ORDER BY id DESC
  `).all(req.params.module).map((record) => ({
    ...record,
    payload: JSON.parse(record.payload || '{}')
  }));
  res.json({ records });
});

app.post('/api/records', (req, res) => {
  const { module, payload = {} } = req.body || {};
  if (!module || typeof module !== 'string' || typeof payload !== 'object') {
    return res.status(400).json({ message: 'module and payload are required' });
  }
  if (!canAccessModule(req.user, module)) return res.status(403).json({ message: `Permission required: ${module}` });
  const result = database.prepare(
    'INSERT INTO app_records (module, payload) VALUES (?, ?)'
  ).run(module, JSON.stringify(payload));
  logActivity(`Created ${module} record`, module, { id: result.lastInsertRowid });
  const record = database.prepare(`
    SELECT id, module, payload, created_at AS createdAt, updated_at AS updatedAt
    FROM app_records WHERE id = ?
  `).get(result.lastInsertRowid);
  res.status(201).json({
    record: { ...record, payload: JSON.parse(record.payload) }
  });
});

app.put('/api/students/:id', requireModule('students'), (req, res) => {
  const { id } = req.params;
  const { name, father, dept, room, phone, status = 'Active', email } = req.body || {};
  const hasEmail = Object.prototype.hasOwnProperty.call(req.body || {}, 'email');
  const normalizedEmail = hasEmail ? String(email || '').trim().toLowerCase() : null;
  if (!name || !dept) return res.status(400).json({ message: 'name and dept are required' });
  if (normalizedEmail && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalizedEmail)) {
    return res.status(400).json({ message: 'Enter a valid student email address' });
  }
  const roomRecord = room && room !== 'Unassigned'
    ? database.prepare('SELECT id FROM rooms WHERE room_number = ? LIMIT 1').get(room)
    : null;
  try {
    const result = database.prepare(`
      INSERT INTO students (id, full_name, father_name, department, email, room_id, phone, status)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(id) DO UPDATE SET full_name = excluded.full_name,
      father_name = excluded.father_name, department = excluded.department,
      room_id = excluded.room_id, phone = excluded.phone, status = excluded.status,
      email = CASE WHEN ? THEN excluded.email ELSE students.email END,
      updated_at = CURRENT_TIMESTAMP
    `).run(Number(id), name, father || '', dept, normalizedEmail || '', roomRecord?.id || null, phone || '', status, Number(hasEmail));
    logActivity('Student saved', 'Students', { id: Number(id), changes: result.changes });
    res.status(201).json({ ok: true });
  } catch (error) {
    if (error.code === 'SQLITE_CONSTRAINT_UNIQUE') return res.status(409).json({ message: 'That email is already linked to another student' });
    throw error;
  }
});

app.delete('/api/students/:id', requireModule('students'), (req, res) => {
  const result = database.prepare('DELETE FROM students WHERE id = ?').run(Number(req.params.id));
  if (!result.changes) return res.status(404).json({ message: 'Student not found' });
  logActivity('Student deleted', 'Students', { id: Number(req.params.id) });
  res.json({ ok: true });
});

app.put('/api/rooms/:roomNumber', requireModule('rooms'), (req, res) => {
  const { roomNumber, capacity, occupiedBeds = 0, floor = 1 } = req.body || {};
  if (!roomNumber || Number(capacity) < 1 || Number(occupiedBeds) < 0 || Number(occupiedBeds) > Number(capacity)) {
    return res.status(400).json({ message: 'Valid room number, capacity and occupancy are required' });
  }
  const result = database.prepare(`
    UPDATE rooms SET room_number = ?, capacity = ?, occupied_beds = ?, floor = ?
    WHERE hostel_id = 1 AND room_number = ?
  `).run(String(roomNumber), Number(capacity), Number(occupiedBeds), Number(floor), String(req.params.roomNumber));
  if (!result.changes) return res.status(404).json({ message: 'Room not found' });
  logActivity('Room updated', 'Rooms', { roomNumber });
  res.json({ ok: true });
});

app.delete('/api/rooms/:roomNumber', requireModule('rooms'), (req, res) => {
  const result = database.prepare('DELETE FROM rooms WHERE hostel_id = 1 AND room_number = ?').run(String(req.params.roomNumber));
  if (!result.changes) return res.status(404).json({ message: 'Room not found' });
  logActivity('Room deleted', 'Rooms', { roomNumber: req.params.roomNumber });
  res.json({ ok: true });
});

app.post('/api/sync', (req, res) => {
  const { students = [], rooms = [], warnings = [], records = [] } = req.body || {};
  for (const [module, entries] of [['students', students], ['rooms', rooms], ['warnings', warnings]]) {
    if (entries.length && !canAccessModule(req.user, module)) return res.status(403).json({ message: `Permission required: ${module}` });
  }
  if (records.some((record) => !canAccessModule(req.user, record.module))) {
    return res.status(403).json({ message: 'One or more records require additional module permissions' });
  }
  const sync = database.transaction(() => {
    const upsertRoom = database.prepare(`
      INSERT INTO rooms (hostel_id, room_number, capacity, occupied_beds)
      VALUES (1, ?, ?, ?)
      ON CONFLICT(hostel_id, room_number) DO UPDATE SET capacity = excluded.capacity,
        occupied_beds = excluded.occupied_beds
    `);
    rooms.forEach(([number, capacity, occupied]) => upsertRoom.run(String(number), Number(capacity), Number(occupied)));
    const upsertStudent = database.prepare(`
      INSERT INTO students (id, full_name, father_name, department, email, room_id, phone, status)
      VALUES (?, ?, ?, ?, ?, (SELECT id FROM rooms WHERE hostel_id = 1 AND room_number = ?), ?, ?)
      ON CONFLICT(id) DO UPDATE SET full_name = excluded.full_name,
        father_name = excluded.father_name, department = excluded.department,
        room_id = excluded.room_id, phone = excluded.phone, status = excluded.status,
        email = CASE WHEN excluded.email <> '' THEN excluded.email ELSE students.email END,
        updated_at = CURRENT_TIMESTAMP
    `);
    students.forEach((student) => upsertStudent.run(
      Number(student.id), student.name, student.father || '', student.dept, String(student.email || '').trim().toLowerCase(),
      student.room === 'Unassigned' ? null : String(student.room), student.phone || '', student.status || 'Active'
    ));
    const upsertWarning = database.prepare(`
      INSERT INTO warning_applications (student_name, room_number, application_count,
        violation_type, application_date, status)
      VALUES (?, ?, ?, ?, ?, ?)
    `);
    warnings.forEach((warning) => {
      const existing = database.prepare(`
        SELECT id FROM warning_applications WHERE student_name = ? ORDER BY id DESC LIMIT 1
      `).get(warning.student);
      if (existing) {
        database.prepare(`UPDATE warning_applications SET room_number = ?, application_count = ?,
          violation_type = ?, application_date = ?, status = ? WHERE id = ?`).run(
          warning.room || '', Number(warning.count), warning.type, warning.date, warning.status, existing.id
        );
      } else {
        upsertWarning.run(warning.student, warning.room || '', Number(warning.count), warning.type, warning.date, warning.status);
      }
    });
    const replaceRecords = database.prepare('DELETE FROM app_records WHERE module = ?');
    const insertRecord = database.prepare('INSERT INTO app_records (module, payload) VALUES (?, ?)');
    const groupedRecords = new Map();
    records.forEach((record) => {
      if (!record?.module || typeof record.payload !== 'object') return;
      if (!groupedRecords.has(record.module)) groupedRecords.set(record.module, []);
      groupedRecords.get(record.module).push(record.payload);
    });
    groupedRecords.forEach((payloads, module) => {
      replaceRecords.run(module);
      payloads.forEach((payload) => insertRecord.run(module, JSON.stringify(payload)));
    });
  });
  sync();
  logActivity('Frontend state synchronized', 'System', { students: students.length, rooms: rooms.length, warnings: warnings.length, records: records.length });
  res.json({ ok: true, state: getState(req.user) });
});

app.use((req, res, next) => {
  if (req.path.startsWith('/api/')) return res.status(404).json({ message: 'API route not found' });
  next();
});

app.listen(port, host, () => {
  const address = host === '0.0.0.0' || host === '::' ? 'all network interfaces' : `${host}:${port}`;
  console.log(`Smart Hostel listening on ${address} (local: http://localhost:${port})`);
});
