INSERT OR IGNORE INTO users (username, email, password_hash, full_name, role)
VALUES ('admin', 'admin@example.com', 'demo:1234', 'Administrator', 'admin');

UPDATE users SET must_change_password = 1
WHERE username = 'admin' AND password_hash = 'demo:1234';

DELETE FROM users
WHERE role = 'student'
  AND (username, email) IN (
    ('student1001', 'ahmed.khan@student.example'),
    ('student1002', 'ali.raza@student.example'),
    ('student1003', 'hassan.ahmed@student.example'),
    ('student1004', 'usman.khan@student.example')
  );

INSERT OR IGNORE INTO hostels (id, name, hostel_type, floors)
VALUES (1, 'Hostel A', 'Male', 3), (2, 'Hostel B', 'Male', 2), (3, 'Hostel C', 'Female', 2);

INSERT OR IGNORE INTO rooms (hostel_id, room_number, capacity, occupied_beds, floor) VALUES
(1, '101', 4, 4, 1), (1, '102', 4, 3, 1), (1, '103', 4, 2, 1),
(1, '104', 4, 4, 1), (1, '201', 4, 1, 2), (1, '202', 4, 4, 2),
(1, '203', 4, 3, 2), (1, '204', 4, 2, 2), (1, '205', 4, 4, 2),
(1, '301', 4, 2, 3), (1, '302', 4, 3, 3), (1, '303', 4, 4, 3);

INSERT OR IGNORE INTO students (id, full_name, father_name, department, email, room_id, phone) VALUES
(1001, 'Ahmed Khan', 'Muhammad Khan', 'CIT', 'ahmed.khan@student.example', (SELECT id FROM rooms WHERE room_number = '203' AND hostel_id = 1), '0300-1111111'),
(1002, 'Ali Raza', 'Raza Ahmed', 'Mechanical', 'ali.raza@student.example', (SELECT id FROM rooms WHERE room_number = '104' AND hostel_id = 1), '0300-2222222'),
(1003, 'Hassan Ahmed', 'Ahmed Ali', 'Civil', 'hassan.ahmed@student.example', (SELECT id FROM rooms WHERE room_number = '201' AND hostel_id = 1), '0300-3333333'),
(1004, 'Usman Khan', 'Khan Muhammad', 'Petroleum', 'usman.khan@student.example', (SELECT id FROM rooms WHERE room_number = '103' AND hostel_id = 1), '0300-4444444');

INSERT INTO warning_applications (student_id, student_name, room_number, application_count, violation_type, application_date, status)
SELECT 1001, 'Ahmed Khan', '203', 2, 'Late Entry', '12 Sep 2026', 'Warning'
WHERE NOT EXISTS (SELECT 1 FROM warning_applications WHERE student_id = 1001);

INSERT INTO warning_applications (student_id, student_name, room_number, application_count, violation_type, application_date, status)
SELECT 1002, 'Ali Raza', '104', 1, 'Noise / Disturbance', '10 Sep 2026', 'Warning'
WHERE NOT EXISTS (SELECT 1 FROM warning_applications WHERE student_id = 1002);

INSERT INTO warning_applications (student_id, student_name, room_number, application_count, violation_type, application_date, status)
SELECT 1004, 'Usman Khan', '103', 3, 'Unauthorized Absence', '15 Sep 2026', 'Stuck-Off Notice'
WHERE NOT EXISTS (SELECT 1 FROM warning_applications WHERE student_id = 1004);

INSERT OR IGNORE INTO attendance_records (student_id, attendance_date, status) VALUES
	(1001, date('now', '-2 day'), 'Present'),
	(1001, date('now', '-1 day'), 'Present'),
	(1002, date('now', '-2 day'), 'Absent'),
	(1002, date('now', '-1 day'), 'Present');

INSERT INTO fee_records (student_id, description, amount, paid_amount, due_date, status, receipt_number)
SELECT 1001, 'September 2026 Hostel Fee', 8000, 8000, '2026-09-30', 'PAID', 'RCP-1001-0926'
WHERE NOT EXISTS (SELECT 1 FROM fee_records WHERE receipt_number = 'RCP-1001-0926');

INSERT INTO notices (title, body, category)
SELECT 'Hostel Maintenance Notice', 'Scheduled maintenance may affect selected common areas. Please follow warden instructions.', 'Maintenance'
WHERE NOT EXISTS (SELECT 1 FROM notices WHERE title = 'Hostel Maintenance Notice');

INSERT INTO notices (title, body, category)
SELECT 'Fee Reminder', 'Monthly hostel fees should be cleared before the due date.', 'Fees'
WHERE NOT EXISTS (SELECT 1 FROM notices WHERE title = 'Fee Reminder');

INSERT INTO mess_menu (menu_date, breakfast, lunch, dinner, announcement)
SELECT date('now'), 'Paratha + Egg', 'Daal + Rice', 'Chicken + Roti', 'Friday menu has been updated.'
WHERE NOT EXISTS (SELECT 1 FROM mess_menu WHERE menu_date = date('now'));
