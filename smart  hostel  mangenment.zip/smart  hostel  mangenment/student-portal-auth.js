function getStudentApiBase(){
if(window.location.protocol==="file:")return "http://localhost:3000/api";
const hostname=window.location.hostname;
const isLocalHost=hostname==="localhost"||hostname.endsWith(".localhost")||hostname==="::1"||hostname==="[::1]"||/^127\./.test(hostname)||/^10\./.test(hostname)||/^192\.168\./.test(hostname)||/^172\.(1[6-9]|2\d|3[01])\./.test(hostname);
if(isLocalHost&&window.location.port!=="3000"){
const localServer=new URL(window.location.origin);
localServer.port="3000";
return `${localServer.origin}/api`;
}
return "/api";
}
const studentApiBase=getStudentApiBase();

function fetchWithTimeout(url, options={}){
const timeoutMs=Number(options.timeoutMs ?? 4000);
if(options.signal)return fetch(url,options);
if(typeof AbortSignal !== "undefined" && typeof AbortSignal.timeout === "function"){
return fetch(url,{...options,signal:AbortSignal.timeout(timeoutMs)});
}
const controller=new AbortController();
const timer=setTimeout(()=>controller.abort(),timeoutMs);
return fetch(url,{...options,signal:controller.signal}).finally(()=>clearTimeout(timer));
}

async function checkStudentServer(){
const status=document.getElementById("studentServerStatus");
const offlineMessage=navigator.onLine===false?
"Browser is offline · reconnect to the internet or use the local hostel server":
"Hostel server unavailable · connect to local server";
try{
const response=await fetchWithTimeout(`${studentApiBase}/health`,{cache:"no-store",timeoutMs:4000});
const result=response.ok?await response.json():null;
const connected=Boolean(result?.ok);
status.textContent=connected?"Hostel server available · internet not required":offlineMessage;
status.classList.toggle("connected",connected);
status.classList.toggle("disconnected",!connected);
}catch(error){
status.textContent=offlineMessage;
status.classList.remove("connected");
status.classList.add("disconnected");
}
}

function showStudentAuthForm(mode){
const showSignup=mode==="signup";
document.getElementById("studentLoginForm").hidden=showSignup;
document.getElementById("studentSignupForm").hidden=!showSignup;
document.getElementById("studentSignInTab").classList.toggle("active",!showSignup);
document.getElementById("studentSignInTab").setAttribute("aria-pressed",String(!showSignup));
document.getElementById("studentSignUpTab").classList.toggle("active",showSignup);
document.getElementById("studentSignUpTab").setAttribute("aria-pressed",String(showSignup));
document.getElementById("studentAuthTitle").textContent=showSignup?"Create Student Account":"Student Portal";
document.getElementById("studentAuthMessage").textContent="";
document.getElementById("studentAuthMessage").classList.remove("success");
}

checkStudentServer();
window.setInterval(checkStudentServer,15000);
window.addEventListener("online",checkStudentServer);
window.addEventListener("offline",checkStudentServer);

async function studentLogin(){
const button=document.getElementById("studentLoginButton");
const message=document.getElementById("studentAuthMessage");
button.disabled=true;
button.textContent="Signing in...";
message.textContent="";
message.classList.remove("success");
try{
const response=await fetchWithTimeout(`${studentApiBase}/auth/login`,{
method:"POST",
headers:{"Content-Type":"application/json"},
body:JSON.stringify({
username:document.getElementById("studentLoginUsername").value.trim(),
password:document.getElementById("studentLoginPassword").value
}),
timeoutMs:4000
});
const result=await response.json();
if(!response.ok)throw new Error(result.message||"Student sign-in failed");
if(result.user?.role!=="student")throw new Error("This is not a student account. Use the Admin / Staff Login page.");
sessionStorage.setItem("hostel_student_login",JSON.stringify({user:result.user,token:result.token}));
window.location.assign("./smart_hostel_management_frontend_v2.html?student=1");
}catch(error){
message.textContent=navigator.onLine===false?
"The browser is offline. Reconnect to the internet or try the local hostel server.":
(error instanceof TypeError?"The hostel server is unavailable. Please try again later.":error.message);
}finally{
button.disabled=false;
button.textContent="Student Login";
}
}

async function studentSignup(){
const button=document.getElementById("studentSignupButton");
const message=document.getElementById("studentAuthMessage");
button.disabled=true;
button.textContent="Sending request...";
message.textContent="";
message.classList.remove("success");
try{
const response=await fetchWithTimeout(`${studentApiBase}/auth/student/password-request`,{
method:"POST",
headers:{"Content-Type":"application/json"},
body:JSON.stringify({
fullName:document.getElementById("signupName").value.trim(),
department:document.getElementById("signupDepartment").value.trim(),
roomNumber:document.getElementById("signupRoom").value.trim()
}),
timeoutMs:4000
});
const result=await response.json();
if(!response.ok)throw new Error(result.message||"Password request could not be sent");
message.textContent=`${result.message} Your login ID is ${result.username}. Give this ID to the administrator when collecting your password.`;
message.classList.add("success");
document.getElementById("studentSignupForm").reset();
}catch(error){
message.textContent=navigator.onLine===false?
"The browser is offline. Reconnect to the internet or try again when the hostel server is available.":
(error instanceof TypeError?"The hostel server is unavailable. Please try again later.":error.message);
message.classList.remove("success");
}finally{
button.disabled=false;
button.textContent="Get Password";
}
}
