const { spawn } = require("node:child_process");
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");
const assert = require("node:assert/strict");
const Database = require("better-sqlite3");

(async () => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), "hostel-auth-"));
  const legacyDatabase = new Database(path.join(directory, "test.sqlite"));
  const legacySchema = fs.readFileSync(path.join(process.cwd(), "database", "schema.sql"), "utf8")
    .replace(/\s+student_id INTEGER REFERENCES students\(id\) ON DELETE CASCADE,/, "")
    .replace(/\s+email TEXT NOT NULL DEFAULT '',/, "");
  legacyDatabase.exec(legacySchema);
  legacyDatabase.close();
  const child = spawn(process.execPath, ["server.js"], {
    cwd: process.cwd(),
    env: { ...process.env, PORT: "41739", HOSTEL_DATABASE_PATH: path.join(directory, "test.sqlite"), AUTH_SECRET: "isolated-test-secret" },
    stdio: "ignore"
  });
  const base = "http://127.0.0.1:41739/api";
  async function request(route, method = "GET", body, token) {
    const headers = {};
    if (body !== undefined) headers["Content-Type"] = "application/json";
    if (token) headers.Authorization = `Bearer ${token}`;
    const response = await fetch(base + route, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) });
    return { status: response.status, data: await response.json() };
  }
  try {
    let ready = false;
    for (let attempt = 0; attempt < 40; attempt++) {
      if (child.exitCode !== null) throw new Error("server exited before health check");
      try { if ((await fetch(base + "/health")).ok) { ready = true; break; } } catch {}
      await new Promise(resolve => setTimeout(resolve, 150));
    }
    assert(ready, "temporary server did not start");
    const testDatabase = new Database(path.join(directory, "test.sqlite"));
    testDatabase.prepare("INSERT INTO fee_records (student_id, description, amount, due_date) VALUES (?, ?, ?, ?)").run(1002, "Other student's utility bill", 500, "2026-10-10");
    const insertFeeRecord = testDatabase.prepare("INSERT INTO app_records (module, payload) VALUES ('fees', ?)");
    insertFeeRecord.run(JSON.stringify({ student: "Ahmed Khan", amount: "1200", month: "October 2026" }));
    insertFeeRecord.run(JSON.stringify({ student: "Ali Raza", amount: "500", month: "Utility" }));
    testDatabase.prepare("INSERT INTO students (id, full_name, department, email) VALUES (?, ?, ?, ?)").run(1005, "Portal Student", "CIT", "portal.student@example.com");
    testDatabase.prepare("INSERT INTO students (id, full_name, department, email) VALUES (?, ?, ?, ?)").run(1006, "Second Portal Student", "Civil", "second.portal@example.com");
    const insertLeave = testDatabase.prepare("INSERT INTO leave_requests (student_id, leave_type, start_date, end_date, reason, emergency_contact, status) VALUES (?, ?, ?, ?, ?, ?, ?)");
    insertLeave.run(1005, "Family visit", "2026-10-10", "2026-10-12", "Family event", "03000000000", "Approved");
    insertLeave.run(1002, "Personal", "2026-10-11", "2026-10-11", "Personal matter", "03000000001", "Pending");
    testDatabase.close();
    assert.equal((await request("/users")).status, 401, "staff list requires authentication");
    const adminLogin = await request("/auth/login", "POST", { username: "admin", password: "1234" });
    assert.equal(adminLogin.status, 200, "seeded admin login works");
    const adminToken = adminLogin.data.token;
    const studentEmailUpdate = await request("/students/1001", "PUT", { name: "Ahmed Khan", father: "Muhammad Khan", dept: "CIT", room: "203", phone: "0300-1111111", email: "ahmed.updated@gmail.com" }, adminToken);
    assert.equal(studentEmailUpdate.status, 201, "admin can set the email used to verify student registration");
    const duplicateStudentEmail = await request("/students/1002", "PUT", { name: "Ali Raza", father: "Raza Ahmed", dept: "Mechanical", room: "104", phone: "0300-2222222", email: "ahmed.updated@gmail.com" }, adminToken);
    assert.equal(duplicateStudentEmail.status, 409, "a student email cannot be shared by two student records");
    const syncWithoutEmail = await request("/sync", "POST", { students: [{ id: 1001, name: "Ahmed Khan", father: "Muhammad Khan", dept: "CIT", room: "203", phone: "0300-1111111", status: "Active" }], rooms: [], warnings: [], records: [] }, adminToken);
    assert.equal(syncWithoutEmail.status, 200, "legacy sync payload remains accepted");
    const linkedStudent = (await request("/state", "GET", undefined, adminToken)).data.students.find(student => student.id === 1001);
    assert.equal(linkedStudent.email, "ahmed.updated@gmail.com", "legacy sync does not erase the linked student email");
    const wardenCreate = await request("/users", "POST", { username: "warden_test", fullName: "Test Warden", roleTitle: "Warden", password: "Warden123", role: "warden", permissions: [] }, adminToken);
    assert.equal(wardenCreate.status, 201, "admin can create warden");
    const wardenLogin = await request("/auth/login", "POST", { username: "warden_test", password: "Warden123" });
    assert.equal(wardenLogin.status, 200, "created warden can log in");
    const wardenToken = wardenLogin.data.token;
    assert.equal((await request("/auth/student/register", "POST", { studentId: 1006, username: "wardencreated", password: "Student123" }, wardenToken)).status, 403, "wardens cannot create student accounts");
    assert.equal((await request("/student-accounts", "GET", undefined, wardenToken)).status, 403, "wardens cannot list student account links");
    const escalation = await request("/users", "POST", { username: "warden_two", fullName: "Second Warden", roleTitle: "Warden", password: "Warden123", role: "warden", permissions: [] }, wardenToken);
    assert.equal(escalation.status, 403, "warden cannot create another warden");
    const staffCreate = await request("/users", "POST", { username: "staff_test", fullName: "Test Staff", roleTitle: "Notice Clerk", password: "StaffPass123", role: "staff", permissions: ["notices"] }, wardenToken);
    assert.equal(staffCreate.status, 201, "warden can create staff with module grant");
    const staffLogin = await request("/auth/login", "POST", { username: "staff_test", password: "StaffPass123" });
    assert.equal(staffLogin.status, 200, "created staff login works");
    const staffToken = staffLogin.data.token;
    assert.deepEqual(staffLogin.data.user.permissions, ["notices"], "login returns assigned permission");
    assert.equal((await request("/records/notices", "GET", undefined, staffToken)).status, 200, "staff can read granted module");
    assert.equal((await request("/records/students", "GET", undefined, staffToken)).status, 403, "staff cannot read ungranted module");
    assert.equal((await request("/records", "POST", { module: "notices", payload: { title: "Test" } }, staffToken)).status, 201, "staff can write granted module");
    assert.equal((await request("/records", "POST", { module: "students", payload: { name: "Nope" } }, staffToken)).status, 403, "staff cannot write ungranted module");
    assert.equal((await request("/users", "GET", undefined, staffToken)).status, 403, "staff cannot manage accounts");
    const state = (await request("/state", "GET", undefined, staffToken)).data;
    assert.equal(state.students.length, 0, "ungranted student data is filtered");
    assert.equal((await request("/auth/student/register", "POST", { studentId: 1005, username: "portalstudent", password: "Student123" })).status, 401, "students and anonymous users cannot create student accounts");
    assert.equal((await request("/student-accounts")).status, 401, "student-account directory requires authentication");
    assert.equal((await request("/student-accounts", "GET", undefined, adminToken)).status, 200, "admin can list student account links");
    assert.equal((await request("/auth/student/register", "POST", { studentId: 9999, username: "newportal", password: "Student123" }, adminToken)).status, 404, "admin cannot create an account without an active student record");
    assert.equal((await request("/auth/student/register", "POST", { studentId: 1005, username: "newportal", password: "weak" }, adminToken)).status, 400, "admin student-account creation rejects weak passwords");
    const registration = await request("/auth/student/register", "POST", { studentId: 1005, username: "portalstudent", password: "Student123" }, adminToken);
    assert.equal(registration.status, 201, "admin can create a username and password for an active student record");
    assert.equal(registration.data.user.student_id, 1005, "new login is linked to the selected student record");
    assert.equal(registration.data.token, undefined, "student-account creation does not sign the admin into the student account");
    assert.equal((await request("/auth/student/register", "POST", { studentId: 1005, username: "anothername", password: "Student123" }, adminToken)).status, 409, "a student record cannot have multiple login accounts");
    assert.equal((await request("/auth/student/register", "POST", { studentId: 1006, username: "portalstudent", password: "Student123" }, adminToken)).status, 409, "usernames must remain unique");
    const registeredLogin = await request("/auth/login", "POST", { username: "portalstudent", password: "Student123" });
    assert.equal(registeredLogin.status, 200, "student can sign in with the new username and password");
    const registeredPortal = await request("/student/portal", "GET", undefined, registeredLogin.data.token);
    assert.equal(registeredPortal.data.student.id, 1005, "new account opens its own student portal");
    assert.equal(registeredPortal.data.leaveRequests.length, 1, "student sees their own leave decision");
    assert.equal(registeredPortal.data.leaveRequests[0].status, "Approved", "portal includes leave approval status");
    const studentLogin = await request("/auth/login", "POST", { username: "student1001", password: "student123" });
    assert.equal(studentLogin.status, 200, "seeded student account is linked after database migration");
    assert.equal(studentLogin.data.user.student_id, 1001, "student login carries its linked record ID");
    const studentToken = studentLogin.data.token;
    const studentPermissionsDb = new Database(path.join(directory, "test.sqlite"));
    studentPermissionsDb.prepare("UPDATE users SET permissions_json = ? WHERE id = ?").run(JSON.stringify(["notices"]), studentLogin.data.user.id);
    studentPermissionsDb.close();
    const portal = await request("/student/portal", "GET", undefined, studentToken);
    assert.equal(portal.status, 200, "linked student can load the read-only portal");
    assert.equal(portal.data.student.id, 1001, "portal profile belongs to the authenticated student");
    assert.equal(portal.data.fees.length, 2, "portal returns the signed-in student's structured bill and saved payment");
    assert.deepEqual(portal.data.fees.map(fee => fee.description).sort(), ["October 2026 payment", "September 2026 Hostel Fee"], "other students' utility bills and payments are not exposed");
    assert.equal((await request("/records/notices", "GET", undefined, studentToken)).status, 403, "student cannot read unrestricted records");
    assert.equal((await request("/users", "GET", undefined, studentToken)).status, 403, "student cannot access staff accounts");
    assert.equal((await request("/student/portal", "GET", undefined, adminToken)).status, 403, "admin token cannot use student-only portal route");
    console.log("PASS: admin-only student accounts, staff roles, student portal scope, leave status, and fee isolation");
  } finally {
    child.kill();
    await new Promise(resolve => child.once("exit", resolve));
    fs.rmSync(directory, { recursive: true, force: true });
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
