
const defaultStudents=[
{id:1001,name:"Ahmed Khan",father:"Muhammad Khan",dept:"CIT",room:"203",phone:"0300-1111111",status:"Active"},
{id:1002,name:"Ali Raza",father:"Raza Ahmed",dept:"Mechanical",room:"104",phone:"0300-2222222",status:"Active"},
{id:1003,name:"Hassan Ahmed",father:"Ahmed Ali",dept:"Civil",room:"201",phone:"0300-3333333",status:"Active"},
{id:1004,name:"Usman Khan",father:"Khan Muhammad",dept:"Petroleum",room:"103",phone:"0300-4444444",status:"Active"}
];
const defaultRooms=[
["101",4,4],["102",4,3],["103",4,2],["104",4,4],["201",4,1],["202",4,4],["203",4,3],["204",4,2],["205",4,4],["301",4,2],["302",4,3],["303",4,4]
];
let students=JSON.parse(localStorage.getItem("hostel_students")||"null")||defaultStudents;
let rooms=JSON.parse(localStorage.getItem("hostel_rooms")||"null")||defaultRooms;
let warnings=JSON.parse(localStorage.getItem("hostel_warnings")||"null")||[
{student:"Ahmed Khan",room:"203",count:2,type:"Late Entry",date:"12 Sep 2026",status:"Warning"},
{student:"Ali Raza",room:"104",count:1,type:"Noise / Disturbance",date:"10 Sep 2026",status:"Warning"},
{student:"Usman Khan",room:"103",count:3,type:"Unauthorized Absence",date:"15 Sep 2026",status:"Stuck-Off Notice"}
];
let records=JSON.parse(localStorage.getItem("hostel_records")||"null")||[];
let attendance=JSON.parse(localStorage.getItem("hostel_attendance")||"null")||{};
let currentUser=null;
let sessionToken=null;
let studentPortalData=null;
let mustChangePassword=false;
let studentAccounts={};
let editingStudentId=null;
let editingRoomNumber=null;
function getApiBase(){
if(window.location.protocol==="file:")return "http://localhost:3000/api";
let hostname=window.location.hostname;
let isLocalHost=hostname==="localhost"||hostname.endsWith(".localhost")||hostname==="::1"||hostname==="[::1]"||/^127\./.test(hostname)||/^10\./.test(hostname)||/^192\.168\./.test(hostname)||/^172\.(1[6-9]|2\d|3[01])\./.test(hostname);
if(isLocalHost&&window.location.port!=="3000"){
let localServer=new URL(window.location.origin);localServer.port="3000";
return `${localServer.origin}/api`;
}
return "/api";
}
const apiBase=getApiBase();
function fetchWithTimeout(url, options={}){
const timeoutMs=Number(options.timeoutMs ?? 4000);
if(options.signal)return fetch(url,options);
if(typeof AbortSignal !== "undefined" && typeof AbortSignal.timeout === "function"){
return fetch(url,{...options,signal:AbortSignal.timeout(timeoutMs)});
}
const controller=new AbortController();
const timer=setTimeout(()=>controller.abort(),timeoutMs);
return fetch(url,{...options,signal:controller.signal}).finally(()=>clearTimeout(timer));
}
function getOfflineStatusMessage(){
if(navigator.onLine===false){
return "Browser is offline · reconnect to the internet or use the local hostel server";
}
return "Hostel server unavailable · connect to local server";
}
async function checkHostelServer(){
let statusText=getOfflineStatusMessage();
let connected=false;
try{
let response=await fetchWithTimeout(`${apiBase}/health`,{cache:"no-store",timeoutMs:4000});
if(response.ok){
let result=await response.json();
if(result.ok){connected=true;statusText="Hostel server available · internet not required"}
}
}catch(error){
if(navigator.onLine===false){statusText="Browser is offline · reconnect to the internet or use the local hostel server";}
}
document.querySelectorAll("#loginServerStatus,#appServerStatus").forEach((element)=>{
element.textContent=statusText;
element.classList.toggle("connected",connected);
element.classList.toggle("disconnected",!connected);
});
}
const moduleLabels={dashboard:"Dashboard",students:"Students",rooms:"Rooms",hostels:"Hostels",fees:"Fees",warnings:"Warnings",complaints:"Complaints",leave:"Leave requests",attendance:"Attendance",notices:"Notices",mess:"Mess menu",facilities:"Facilities",reports:"Reports",activity:"Activity logs",committees:"Committees",stock:"Mess stock",applications:"Applications",mailbox:"Mailbox",notifications:"Notifications"};
const originalFetch=window.fetch.bind(window);
window.fetch=(resource,options={})=>{
let requestUrl=typeof resource==="string"?resource:resource.url;
if(!new URL(requestUrl,window.location.href).pathname.startsWith("/api/")||!sessionToken)return originalFetch(resource,options);
let headers=new Headers(options.headers||{});headers.set("Authorization",`Bearer ${sessionToken}`);
return originalFetch(resource,{...options,headers});
};
const offlineStaffAccountsKey="hostel_offline_staff_accounts";
function getOfflineStaffAccounts(){
try{let accounts=JSON.parse(localStorage.getItem(offlineStaffAccountsKey)||"[]");return Array.isArray(accounts)?accounts:[]}catch(error){return []}
}
function isNetworkUnavailable(error){return !navigator.onLine||error instanceof TypeError}
async function hashOfflinePassword(password,salt){
if(!crypto.subtle)throw new Error("Secure offline password storage is unavailable in this browser");
let key=await crypto.subtle.importKey("raw",new TextEncoder().encode(password),"PBKDF2",false,["deriveBits"]);
let bits=await crypto.subtle.deriveBits({name:"PBKDF2",salt:new TextEncoder().encode(salt),iterations:120000,hash:"SHA-256"},key,256);
return [...new Uint8Array(bits)].map(byte=>byte.toString(16).padStart(2,"0")).join("");
}
async function authenticateOfflineStaff(username,password){
let normalizedUsername=String(username||"").trim().toLowerCase();
for(let account of getOfflineStaffAccounts()){
if(account.is_active===false||(account.username!==normalizedUsername&&account.email!==normalizedUsername))continue;
let passwordHash=await hashOfflinePassword(password,account.passwordSalt);
if(passwordHash===account.passwordHash)return {id:account.id,username:account.username,email:account.email,full_name:account.full_name,role:account.role,role_title:account.role_title,permissions:account.permissions||[]};
}
return null;
}
let guestMode=false;
const guestPageIds=["guestOverview","guestFacilities","guestNotices"];
const studentPageIds=["studentPortal"];
async function loadRemoteState(){
try{
let response=await fetch(`${apiBase}/state`);if(!response.ok)return false;
let state=await response.json();
if(Array.isArray(state.students))students=state.students;
if(Array.isArray(state.rooms))rooms=state.rooms;
if(Array.isArray(state.warnings))warnings=state.warnings;
if(Array.isArray(state.records))records=state.records;
localStorage.setItem("hostel_students",JSON.stringify(students));
localStorage.setItem("hostel_rooms",JSON.stringify(rooms));
localStorage.setItem("hostel_warnings",JSON.stringify(warnings));
localStorage.setItem("hostel_records",JSON.stringify(records));
renderPersistedRecords();
return true;
}catch(error){return false}
}

async function loadStudentPortal(){
let status=document.getElementById("studentPortalStatus");
status.textContent="Loading your hostel information...";
try{
let response=await fetch(`${apiBase}/student/portal`),data=await response.json();
if(!response.ok)throw new Error(data.message||"Student information could not be loaded");
studentPortalData=data;renderStudentPortal(data);status.textContent="";
}catch(error){status.textContent=error.message}
}
function studentCurrency(amount){return `Rs. ${Number(amount||0).toLocaleString("en-PK")}`}
function renderStudentPortal(data){
let student=data.student,occupancy=data.reports?.occupancy||{},attendanceSummary=data.reports?.attendance||{};
document.getElementById("studentAvatar").textContent=student.name.charAt(0).toUpperCase();
document.getElementById("studentName").textContent=student.name;
document.getElementById("studentDetails").textContent=`Student ID #${student.id} · ${student.department} · Room ${student.room}`;
let availableBeds=Number(occupancy.availableBeds||0),balance=data.fees.reduce((sum,fee)=>sum+Math.max(0,Number(fee.balance||0)),0);
let totalDays=Number(attendanceSummary.totalDays||0),presentDays=Number(attendanceSummary.presentDays||0),absentDays=Number(attendanceSummary.absentDays||0);
document.getElementById("portalAvailableBeds").textContent=availableBeds;
document.getElementById("portalBalance").textContent=studentCurrency(balance);
document.getElementById("portalAttendanceRate").textContent=`${totalDays?Math.round(presentDays/totalDays*100):0}%`;
document.getElementById("portalNoticeCount").textContent=data.notices.length;
document.getElementById("portalTotalBeds").textContent=Number(occupancy.totalBeds||0);
document.getElementById("portalOccupiedBeds").textContent=Number(occupancy.occupiedBeds||0);
document.getElementById("portalReportAvailableBeds").textContent=availableBeds;
document.getElementById("portalPresentDays").textContent=presentDays;
document.getElementById("portalAbsentDays").textContent=absentDays;
document.getElementById("portalTotalDays").textContent=totalDays;
document.getElementById("portalAttendanceRows").innerHTML=data.attendance.map(entry=>`<tr><td>${escapeHtml(entry.date)}</td><td><span class="badge ${entry.status==="Present"?"b-green":"b-orange"}">${escapeHtml(entry.status)}</span></td></tr>`).join("")||'<tr><td colspan="2" class="empty">No attendance records yet.</td></tr>';
document.getElementById("portalRoomRows").innerHTML=data.rooms.map(room=>`<tr><td>${escapeHtml(room.hostel)}</td><td>${escapeHtml(room.room)}</td><td>${escapeHtml(room.floor)}</td><td>${escapeHtml(room.capacity)}</td><td>${escapeHtml(room.occupiedBeds)}</td><td>${escapeHtml(room.availableBeds)}</td></tr>`).join("")||'<tr><td colspan="6" class="empty">No room information available.</td></tr>';
document.getElementById("portalFeeRows").innerHTML=data.fees.map(fee=>`<tr><td>${escapeHtml(fee.description)}</td><td>${studentCurrency(fee.amount)}</td><td>${studentCurrency(fee.paidAmount)}</td><td>${studentCurrency(fee.balance)}</td><td>${escapeHtml(fee.dueDate)}</td><td><span class="badge ${fee.balance<=0?"b-green":"b-orange"}">${escapeHtml(fee.status)}</span></td></tr>`).join("")||'<tr><td colspan="6" class="empty">No fees or utility bills are assigned to your account.</td></tr>';
document.getElementById("portalNoticeRows").innerHTML=data.notices.map(notice=>`<article class="notice"><h4>${escapeHtml(notice.title)}</h4><p>${escapeHtml(notice.body)}</p><small>${escapeHtml(notice.category||"Notice")} · ${escapeHtml(notice.publishedAt||"")}</small></article>`).join("")||'<div class="empty">No news or notices have been published.</div>';
document.getElementById("portalMessRows").innerHTML=data.messMenu.map(menu=>`<tr><td>${escapeHtml(menu.date||menu.menuDate||menu.day||menu.publishedAt||"")}</td><td>${escapeHtml(menu.breakfast||"")}</td><td>${escapeHtml(menu.lunch||"")}</td><td>${escapeHtml(menu.dinner||"")}</td><td>${escapeHtml(menu.announcement||menu.notes||"")}</td></tr>`).join("")||'<tr><td colspan="5" class="empty">The mess menu has not been published yet.</td></tr>';
document.getElementById("portalLeaveRows").innerHTML=data.leaveRequests.map(request=>`<tr><td>${escapeHtml(request.leaveType)}</td><td>${escapeHtml(request.startDate)} - ${escapeHtml(request.endDate)}</td><td>${escapeHtml(request.reason)}</td><td><span class="badge ${request.status==="Approved"?"b-green":request.status==="Rejected"?"b-red":"b-orange"}">${escapeHtml(request.status)}</span></td><td>${escapeHtml(request.submittedAt)}</td></tr>`).join("")||'<tr><td colspan="5" class="empty">No leave requests have been submitted.</td></tr>';
document.getElementById("portalApplicationRows").innerHTML=(data.applications||[]).map(application=>`<tr><td>${escapeHtml(application.type)}</td><td>${escapeHtml(application.details)}</td><td><span class="badge ${application.status==="Approved"?"b-green":application.status==="Rejected"?"b-red":"b-orange"}">${escapeHtml(application.status)}</span></td><td>${escapeHtml(application.submittedAt)}</td></tr>`).join("")||'<tr><td colspan="4" class="empty">You have not submitted any applications.</td></tr>';
}
function showStudentTab(tabName,button){
document.querySelectorAll(".student-tab").forEach(tab=>{tab.classList.remove("active");tab.setAttribute("aria-selected","false")});
document.querySelectorAll(".student-panel").forEach(panel=>panel.classList.remove("active"));
button.classList.add("active");button.setAttribute("aria-selected","true");
document.getElementById(`studentTab${tabName.charAt(0).toUpperCase()+tabName.slice(1)}`).classList.add("active");
}
function openStudentApplicationModal(){
if(currentUser?.role!=="student"||mustChangePassword){toast("Sign in with your student account to submit an application");return}
document.getElementById("studentApplicationType").value="Leave";
document.getElementById("studentApplicationDetails").value="";
document.getElementById("studentApplicationStartDate").value="";
document.getElementById("studentApplicationEndDate").value="";
document.getElementById("studentApplicationRoom").value="";
document.getElementById("studentApplicationStatus").textContent="";
document.getElementById("studentApplicationSaveButton").disabled=false;
document.getElementById("studentApplicationSaveButton").textContent="Submit application";
updateStudentApplicationFields();
openModal("studentApplicationModal");
}
function updateStudentApplicationFields(){
let isLeave=document.getElementById("studentApplicationType").value==="Leave";
let isRoomChange=document.getElementById("studentApplicationType").value==="Room Change";
document.getElementById("studentLeaveDates").hidden=!isLeave;
document.getElementById("studentApplicationStartDate").required=isLeave;
document.getElementById("studentApplicationEndDate").required=isLeave;
document.getElementById("studentRequestedRoomGroup").hidden=!isRoomChange;
document.getElementById("studentApplicationRoom").required=isRoomChange;
}
async function submitStudentApplication(){
if(currentUser?.role!=="student"||mustChangePassword){toast("Sign in with your student account to submit an application");return}
let button=document.getElementById("studentApplicationSaveButton"),status=document.getElementById("studentApplicationStatus");
let applicationType=document.getElementById("studentApplicationType").value;
let payload={
applicationType,
details:document.getElementById("studentApplicationDetails").value.trim(),
startDate:document.getElementById("studentApplicationStartDate").value,
endDate:document.getElementById("studentApplicationEndDate").value,
requestedRoom:document.getElementById("studentApplicationRoom").value.trim()
};
status.textContent="";
if(!payload.details){status.textContent="Describe your request before submitting.";return}
if(applicationType==="Leave"&&(!payload.startDate||!payload.endDate||payload.startDate>payload.endDate)){status.textContent="Enter valid leave dates, with the end date on or after the start date.";return}
if(applicationType==="Room Change"&&!payload.requestedRoom){status.textContent="Enter the room you are requesting.";return}
button.disabled=true;button.textContent="Submitting...";
try{
let response=await fetch(`${apiBase}/student/applications`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)});
let result=await response.json();
if(!response.ok)throw new Error(result.message||"Application could not be submitted");
closeModal("studentApplicationModal");toast("Application submitted successfully");await loadStudentPortal();
}catch(error){status.textContent=error.message}
button.disabled=false;button.textContent="Submit application";
}
async function completeLogin(authResult){
let offlineSession=authResult.offline===true;
currentUser=authResult.user;sessionToken=authResult.token||null;studentPortalData=null;guestMode=false;
mustChangePassword=currentUser.role!=="student"&&Boolean(currentUser.must_change_password);
document.body.classList.toggle("student-mode",currentUser.role==="student");
if(currentUser.role==="student"){students=[];rooms=[];warnings=[];records=[]}
updateUserDisplay();
document.getElementById("loginScreen").style.display="none";
document.getElementById("app").style.display="block";
if(currentUser.role==="student"){page("studentPortal",document.querySelector(".nav.student-only"));return}
if(offlineSession){renderAll();openPermittedLandingPage();toast("Signed in with a browser-only offline staff account");return}
renderAll();let connected=mustChangePassword?false:await loadRemoteState();renderAll();openPermittedLandingPage();toast(mustChangePassword?"Set your new password to continue":connected?"Connected to hostel database":"Offline demo mode");if(mustChangePassword)openPasswordModal();
}

function toggleLoginPassword(){
let password=document.getElementById("loginPass"),toggle=document.querySelector(".password-toggle");
let isVisible=password.type==="text";
password.type=isVisible?"password":"text";
toggle.textContent=isVisible?"Show":"Hide";
toggle.setAttribute("aria-label",`${isVisible?"Show":"Hide"} password`);
toggle.setAttribute("aria-pressed",String(!isVisible));
}
function clearLoginError(){
clearTimeout(window.loginErrorTimeout);
let error=document.getElementById("loginError"),card=document.querySelector(".login-card");error.textContent="";error.classList.remove("show");card.classList.remove("login-shake");document.getElementById("loginScreen").classList.remove("login-error-state");
}
function showLoginError(message){
clearTimeout(window.loginErrorTimeout);
let error=document.getElementById("loginError"),card=document.querySelector(".login-card");
error.textContent=message;error.classList.add("show");document.getElementById("loginScreen").classList.add("login-error-state");card.classList.remove("login-shake");void card.offsetWidth;card.classList.add("login-shake");
window.loginErrorTimeout=setTimeout(clearLoginError,4000);
}
async function login(){
let u=document.getElementById("loginUser").value,p=document.getElementById("loginPass").value;
clearLoginError();
try{
let auth=await fetchWithTimeout(`${apiBase}/auth/login`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({username:u,password:p}),timeoutMs:4000});
let result=await auth.json();
if(!auth.ok){
if(auth.status===401){let offlineUser=await authenticateOfflineStaff(u,p);if(offlineUser){await completeLogin({user:offlineUser,offline:true});return}}
showLoginError(auth.status===401?"Invalid username or password":result.message||"Login could not be completed");return
}
if(result.user.role==="student"){
showLoginError("Student accounts must sign in through the Student Portal Login.");
return
}
await completeLogin(result);
}catch(error){
try{let offlineUser=await authenticateOfflineStaff(u,p);if(offlineUser){await completeLogin({user:offlineUser,offline:true});return}}catch(offlineError){}
const loginMessage=navigator.onLine===false?
"The browser is offline. Reconnect to the internet or sign in with a browser-only offline staff account.":
"The hostel server is unavailable. Reconnect or use a browser-only offline staff login.";
showLoginError(loginMessage);
}
}
function enterGuestMode(){
guestMode=true;
document.body.classList.add("guest-mode");
document.getElementById("loginScreen").style.display="none";
document.getElementById("app").style.display="block";
document.querySelectorAll("#sidebar .nav:not(.guest-only)").forEach((nav)=>nav.style.display="none");
document.querySelector(".user-text b").textContent="Guest visitor";
document.querySelector(".user-text small").textContent="Public access";
document.querySelector(".avatar").textContent="G";
page("guestOverview",document.querySelector(".nav.guest-only"));
}
function updateUserDisplay(){
let name=currentUser?.full_name||"Administrator";let role=currentUser?.role||"admin";
document.querySelector(".user-text b").textContent=name;
document.querySelector(".user-text small").textContent=currentUser?.role_title||`${role.charAt(0).toUpperCase()+role.slice(1)} Account`;
document.querySelector(".avatar").textContent=name.charAt(0).toUpperCase();
applyRoleAccess();
}
function logout(){
guestMode=false;
currentUser=null;
sessionToken=null;
studentPortalData=null;
mustChangePassword=false;
document.body.classList.remove("guest-mode","student-mode");
document.querySelectorAll("#sidebar .nav").forEach((nav)=>nav.style.display="");
document.querySelector(".user-text b").textContent="Administrator";
document.querySelector(".user-text small").textContent="Admin Account";
document.querySelector(".avatar").textContent="A";
document.getElementById("app").style.display="none";
document.getElementById("loginScreen").style.display="grid";
}
function openPasswordModal(){
if(!currentUser){toast("Log in through the server to change your password");return}
["currentPassword","newPassword","confirmPassword"].forEach((id)=>document.getElementById(id).value="");
document.getElementById("passwordError").classList.remove("show");
document.getElementById("passwordMeter").style.width="0";
document.getElementById("passwordHint").textContent="Use 8+ characters with uppercase, lowercase and a number.";
document.getElementById("passwordSaveButton").disabled=false;
document.getElementById("passwordModalTitle").textContent=mustChangePassword?"Set a new password":"Change password";
document.getElementById("passwordModalIntro").textContent=mustChangePassword?"Your administrator-issued temporary password must be replaced before you can use the student portal.":"Choose a password you do not use elsewhere.";
document.getElementById("passwordCloseButton").hidden=mustChangePassword;
document.getElementById("passwordCancelButton").hidden=mustChangePassword;
openModal("passwordModal");
}
function updatePasswordStrength(){
let password=document.getElementById("newPassword").value;let score=[password.length>=8,/[A-Z]/.test(password),/[a-z]/.test(password),/\d/.test(password)].filter(Boolean).length;
let meter=document.getElementById("passwordMeter");let hint=document.getElementById("passwordHint");meter.style.width=`${score*25}%`;meter.style.background=score<2?"#d9363e":score<4?"#e59a18":"#219653";hint.textContent=score===4?"Strong password":"Use 8+ characters with uppercase, lowercase and a number.";
}
async function changePassword(){
let currentPassword=document.getElementById("currentPassword").value;let newPassword=document.getElementById("newPassword").value;let confirmPassword=document.getElementById("confirmPassword").value;let error=document.getElementById("passwordError");let button=document.getElementById("passwordSaveButton");
error.classList.remove("show");
if(!currentPassword||!newPassword||!confirmPassword){error.textContent="Complete all password fields.";error.classList.add("show");return}
if(newPassword!==confirmPassword){error.textContent="New passwords do not match.";error.classList.add("show");return}
if(newPassword.length<8||!/[A-Z]/.test(newPassword)||!/[a-z]/.test(newPassword)||!/\d/.test(newPassword)){error.textContent="Use at least 8 characters with uppercase, lowercase and a number.";error.classList.add("show");return}
button.disabled=true;button.textContent="Updating...";
try{
let response=await fetch(`${apiBase}/auth/change-password`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({userId:currentUser.id,currentPassword,newPassword})});let result=await response.json();
if(!response.ok)throw new Error(result.message||"Password could not be changed");
mustChangePassword=false;currentUser.must_change_password=false;closeModal("passwordModal");toast("Password changed successfully");if(currentUser.role==="student")loadStudentPortal();
}catch(error){document.getElementById("passwordError").textContent=error.message;document.getElementById("passwordError").classList.add("show");}
button.disabled=false;button.textContent="Update password";
}
function toggleSidebar(){let isOpen=document.getElementById("sidebar").classList.toggle("open");let button=document.querySelector(".hamb");button.setAttribute("aria-expanded",String(isOpen));button.setAttribute("aria-label",isOpen?"Close navigation menu":"Open navigation menu")}
function canAccessModule(module){if(module==="mailbox")return currentUser?.role==="admin";return currentUser?.role!=="student"&&(currentUser?.role==="admin"||currentUser?.role==="warden"||(currentUser?.permissions||[]).includes(module))}
function applyRoleAccess(){
let isStudent=currentUser?.role==="student";
document.querySelectorAll("#sidebar .nav:not(.guest-only):not(.student-only)").forEach((nav)=>{
let match=nav.getAttribute("onclick")?.match(/page\('([^']+)'/);let module=match?.[1];
if(module)nav.style.display=canAccessModule(module)?"":"none";
});
document.querySelector(".nav.student-only").style.display=isStudent?"flex":"none";
let createButton=document.getElementById("createStaffLoginButton");if(createButton)createButton.style.display=currentUser?.role==="admin"?"":"none";
document.querySelectorAll("#staffAccountRole").forEach((select)=>{let wardenOption=select.querySelector('option[value="warden"]');if(wardenOption)wardenOption.hidden=currentUser?.role!=="admin"});
}
function openPermittedLandingPage(){
if(currentUser?.role==="student"){page("studentPortal",document.querySelector(".nav.student-only"));return}
if(canAccessModule("dashboard")){page("dashboard",document.querySelector('#sidebar .nav[onclick*="page(\'dashboard\'"]'));return}
let firstModule=Object.keys(moduleLabels).find((module)=>canAccessModule(module));if(firstModule)page(firstModule,document.querySelector(`#sidebar .nav[onclick*="page('${firstModule}'"]`));
}
const titles={dashboard:"Dashboard",students:"Students",rooms:"Rooms",hostels:"Hostels",wardens:"Wardens / Staff",fees:"Fees & Payments",warnings:"Warning Applications",complaints:"Complaints",leave:"Leave Requests",attendance:"Attendance",notices:"Notices",mess:"Mess Menu",facilities:"Facilities",reports:"Reports",activity:"Activity Logs",settings:"Settings",committees:"Student Committees",stock:"Mess Stock",applications:"Applications",mailbox:"Student Mailbox",notifications:"Notifications",studentPortal:"Student Portal",guestOverview:"Hostel overview",guestFacilities:"Facilities",guestNotices:"Public notices"};
function page(id,el){
if(guestMode&&!guestPageIds.includes(id))return;
let studentView=studentPageIds.includes(id);
if(studentView&&currentUser?.role!=="student"){toast("Student portal access is required");return}
if(!guestMode&&currentUser?.role==="student"&&!studentView){toast("Your login does not have access to this module");return}
if(!guestMode&&!studentView&&!canAccessModule(id)){toast("Your login does not have access to this module");return}
document.querySelectorAll(".page").forEach(x=>x.classList.remove("active"));
document.getElementById(id).classList.add("active");
document.querySelectorAll(".nav").forEach(x=>x.classList.remove("active"));
if(el)el.classList.add("active");
document.getElementById("title").textContent=titles[id]||id;
document.getElementById("sidebar").classList.remove("open");document.querySelector(".hamb").setAttribute("aria-expanded","false");document.querySelector(".hamb").setAttribute("aria-label","Open navigation menu");
if(id==="students"){renderStudents();if(currentUser?.role==="admin")loadStudentAccounts()} if(id==="rooms")renderRooms(); if(id==="warnings")renderWarnings(); if(id==="attendance"){renderAttendance();renderMonthlyAttendance()}
if(id==="mailbox"&&currentUser?.role==="admin")loadStudentAccounts();
if(studentView&&!mustChangePassword)loadStudentPortal();
if(id==="applications"&&currentUser?.role!=="student")loadRemoteState();
if(id==="wardens")loadStaffUsers();
}
function openModal(id){let modal=document.getElementById(id);replaceEmojiIcons(modal);modal.classList.add("show")}
function closeModal(id){document.getElementById(id).classList.remove("show")}
function openStaffLoginModal(){
if(currentUser?.role!=="admin"){toast("Only an administrator can create logins");return}
["staffFullName","staffUsername","staffEmail","staffRoleTitle","staffPassword"].forEach((id)=>document.getElementById(id).value="");
document.getElementById("staffAccountRole").value="staff";
document.querySelectorAll('input[name="staffPermission"]').forEach((input)=>input.checked=false);
openModal("staffModal");
}
async function loadStudentAccounts(){
if(currentUser?.role!=="admin")return;
try{
let response=await fetch(`${apiBase}/student-accounts`),result=await response.json();
if(!response.ok)throw new Error(result.message||"Student account statuses could not be loaded");
studentAccounts=Object.fromEntries(result.accounts.map(account=>[account.studentId,account]));renderStudents();renderStudentPasswordRequests();
}catch(error){
if(isNetworkUnavailable(error)){studentAccounts={};renderStudents();return}
toast(error.message);
}
}
async function toggleStudentAccount(studentId,isActive){
if(currentUser?.role!=="admin"){toast("Only an administrator can activate or deactivate student accounts");return}
try{
let response=await fetch(`${apiBase}/student-accounts/${studentId}/status`,{method:"PATCH",headers:{"Content-Type":"application/json"},body:JSON.stringify({isActive})});
let result=await response.json();
if(!response.ok)throw new Error(result.message||"Student account status could not be changed");
let account=studentAccounts[studentId];
if(account)account.isActive=result.isActive;
let student=students.find(item=>Number(item.id)===Number(studentId));
if(student)student.status=result.isActive?"Active":"Inactive";
renderStudents();
toast(result.isActive?"Student account activated":"Student account deactivated");
}catch(error){toast(error.message||"Student account status could not be changed")}
}
function openStudentAccountModal(studentId){
if(currentUser?.role!=="admin"){toast("Only an administrator can create student logins");return}
let student=students.find(item=>Number(item.id)===Number(studentId));if(!student)return;
if(studentAccounts[studentId]){toast("This student already has a login account");return}
document.getElementById("studentAccountModalTitle").textContent="Create Student Login";
document.getElementById("studentAccountName").textContent=`Create credentials for ${student.name} · #${student.id}`;
let usernameInput=document.getElementById("studentAccountUsername");usernameInput.readOnly=false;usernameInput.value=`student${student.id}`;
document.getElementById("studentAccountPassword").value="";
document.getElementById("studentAccountStatus").textContent="";
document.getElementById("studentAccountSaveButton").dataset.studentId=student.id;
document.getElementById("studentAccountSaveButton").dataset.action="create";
document.getElementById("studentAccountSaveButton").disabled=false;
document.getElementById("studentAccountSaveButton").textContent="Create login";
openModal("studentAccountModal");
}
function renderStudentPasswordRequests(){
let requests=Object.values(studentAccounts).filter(account=>account.passwordPending);
let count=requests.length;
let sidebarCount=document.getElementById("mailboxCount"),pageCount=document.getElementById("mailboxRequestCount"),table=document.getElementById("studentPasswordRequestsTable");
if(sidebarCount){sidebarCount.textContent=count;sidebarCount.hidden=count===0}
if(pageCount)pageCount.textContent=count;
if(table)table.innerHTML=requests.map(account=>`<tr><td>#${account.studentId}</td><td>${escapeHtml(account.name)}</td><td>${escapeHtml(account.dept)}</td><td>${escapeHtml(account.room)}</td><td>${escapeHtml(account.requestCreatedAt?new Date(account.requestCreatedAt+"Z").toLocaleString():"—")}</td><td><button class="btn primary" onclick="openStudentPasswordModal(${account.studentId})">Set password</button></td></tr>`).join("")||'<tr><td colspan="6" class="empty">No password requests.</td></tr>';
}
function openStudentPasswordModal(studentId){
if(currentUser?.role!=="admin"){toast("Only an administrator can issue student passwords");return}
let account=studentAccounts[studentId];if(!account?.passwordPending)return;
document.getElementById("studentAccountModalTitle").textContent="Issue Student Password";
document.getElementById("studentAccountName").textContent=`Give this temporary password to ${account.name} · #${studentId}`;
let usernameInput=document.getElementById("studentAccountUsername");usernameInput.value=account.username;usernameInput.readOnly=true;
document.getElementById("studentAccountPassword").value="";
document.getElementById("studentAccountStatus").textContent="";
let button=document.getElementById("studentAccountSaveButton");button.dataset.studentId=studentId;button.dataset.action="issue";button.disabled=false;button.textContent="Set password and activate";
openModal("studentAccountModal");
}
async function saveStudentAccount(){
let button=document.getElementById("studentAccountSaveButton");
if(button.dataset.action!=="issue"){await saveStudentAccountExisting();return}
let status=document.getElementById("studentAccountStatus"),studentId=Number(button.dataset.studentId);
let password=document.getElementById("studentAccountPassword").value;
status.textContent="";
if(password.length<8||!/[A-Z]/.test(password)||!/[a-z]/.test(password)||!/\d/.test(password)){status.textContent="Use at least 8 characters with uppercase, lowercase and a number.";return}
button.disabled=true;button.textContent="Setting password...";
try{
let response=await fetch(`${apiBase}/student-accounts/${studentId}/password`,{method:"PATCH",headers:{"Content-Type":"application/json"},body:JSON.stringify({password})}),result=await response.json();
if(!response.ok)throw new Error(result.message||"Student password could not be issued");
let account=studentAccounts[studentId];if(account){account.isActive=true;account.passwordPending=false;account.passwordIssuedAt=new Date().toISOString();account.mustChangePassword=false}
let student=students.find(item=>Number(item.id)===studentId);if(student)student.status="Active";
renderStudentPasswordRequests();renderStudents();closeModal("studentAccountModal");toast(`Password set for ${result.username}. Give the login ID and password to the student.`);
}catch(error){status.textContent=isNetworkUnavailable(error)?"The hostel server is offline. Connect to the server to issue passwords.":error.message}
button.disabled=false;button.textContent="Set password and activate";
}
async function saveStudentAccountExisting(){
let button=document.getElementById("studentAccountSaveButton"),status=document.getElementById("studentAccountStatus");
let studentId=Number(button.dataset.studentId),username=document.getElementById("studentAccountUsername").value.trim().toLowerCase(),password=document.getElementById("studentAccountPassword").value;
status.textContent="";
if(!/^[a-z0-9._-]{3,32}$/.test(username)){status.textContent="Username must be 3-32 characters and use letters, numbers, dots, underscores or hyphens.";return}
if(password.length<8||!/[A-Z]/.test(password)||!/[a-z]/.test(password)||!/\d/.test(password)){status.textContent="Use at least 8 characters with uppercase, lowercase and a number.";return}
button.disabled=true;button.textContent="Creating login...";
try{
let response=await fetch(`${apiBase}/auth/student/register`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({studentId,username,password})}),result=await response.json();
if(!response.ok)throw new Error(result.message||"Student login could not be created");
studentAccounts[studentId]={studentId,username:result.user.username,isActive:true,mustChangePassword:false};
renderStudents();closeModal("studentAccountModal");toast(`Student login created for ${result.user.full_name}`);
}catch(error){status.textContent=isNetworkUnavailable(error)?"The hostel server is offline. Connect to the server to create student logins.":error.message}
button.disabled=false;button.textContent="Create login";
}
async function loadStaffUsers(){
if(currentUser?.role!=="admin"&&currentUser?.role!=="warden")return;
let table=document.getElementById("staffTable");if(!table)return;
let serverResponded=false;
try{
let response=await fetch(`${apiBase}/users`);serverResponded=true;let result=await response.json();
if(!response.ok)throw new Error(result.message||"Staff accounts could not be loaded");
renderStaffUsers(result.users,false);
}catch(error){
if(!serverResponded&&isNetworkUnavailable(error)){renderStaffUsers(getOfflineStaffAccounts(),true);return}
table.innerHTML=`<tr><td colspan="5" class="empty">${escapeHtml(error.message)}</td></tr>`
}
}
function renderStaffUsers(users,offline){
let table=document.getElementById("staffTable");if(!table)return;
table.innerHTML=users.map(user=>`<tr><td><b>${escapeHtml(user.full_name)}</b><br><small>${escapeHtml(user.email||"")}</small></td><td>${escapeHtml(user.username)}</td><td>${escapeHtml(user.role_title||user.role)}</td><td>${(user.permissions||[]).map(module=>escapeHtml(moduleLabels[module]||module)).join(", ")||"No module access"}</td><td><span class="badge ${offline?"b-orange":user.is_active?"b-green":"b-red"}">${offline?"Offline demo":user.is_active?"Active":"Inactive"}</span></td></tr>`).join("")||`<tr><td colspan="5" class="empty">${offline?"No browser-only staff logins created yet.":"No staff logins yet."}</td></tr>`;
}
async function createOfflineStaffLogin(account){
let username=account.username.toLowerCase(),email=account.email.toLowerCase(),accounts=getOfflineStaffAccounts();
if(accounts.some(saved=>saved.username===username||(email&&saved.email===email)))throw new Error("That username or email is already used by an offline staff account");
let salt=[...crypto.getRandomValues(new Uint8Array(16))].map(byte=>byte.toString(16).padStart(2,"0")).join("");
let passwordHash=await hashOfflinePassword(account.password,salt);
accounts.unshift({id:`offline-${Date.now()}`,username,email,full_name:account.fullName,role:account.role,role_title:account.roleTitle,permissions:account.permissions,is_active:true,passwordSalt:salt,passwordHash,created_at:new Date().toISOString()});
localStorage.setItem(offlineStaffAccountsKey,JSON.stringify(accounts));
closeModal("staffModal");toast("Staff login saved in this browser's offline demo");await loadStaffUsers();
}
async function saveStaffLogin(){
if(currentUser?.role!=="admin"){toast("Only an administrator can create logins");return}
let fullName=document.getElementById("staffFullName").value.trim(),username=document.getElementById("staffUsername").value.trim().toLowerCase(),email=document.getElementById("staffEmail").value.trim().toLowerCase(),roleTitle=document.getElementById("staffRoleTitle").value.trim(),password=document.getElementById("staffPassword").value,permissions=[...document.querySelectorAll('input[name="staffPermission"]:checked')].map(input=>input.value),role=document.getElementById("staffAccountRole").value,button=document.getElementById("staffSaveButton");
if(!fullName||!username||!roleTitle||!password){toast("Complete all required staff login fields");return}
if(!/^[a-z0-9._-]{3,32}$/.test(username)){toast("Username must be 3-32 characters and use letters, numbers, dots, underscores or hyphens");return}
if(email&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)){toast("Enter a valid email address");return}
if(password.length<8||!/[A-Z]/.test(password)||!/[a-z]/.test(password)||!/\d/.test(password)){toast("Password must be 8+ characters with uppercase, lowercase and a number");return}
if(!permissions.length){toast("Choose at least one module for this staff login");return}
let account={fullName,username,email,roleTitle,password,permissions,role},serverResponded=false;
button.disabled=true;button.textContent="Creating...";
try{
let response=await fetch(`${apiBase}/users`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(account)});serverResponded=true;let result=await response.json();
if(!response.ok)throw new Error(result.message||"Staff login could not be created");
closeModal("staffModal");toast("Staff login created successfully");await loadStaffUsers();
}catch(error){
if(!serverResponded&&isNetworkUnavailable(error)){
try{await createOfflineStaffLogin(account)}catch(offlineError){toast(offlineError.message)}
}else toast(error.message||"Staff login could not be created");
}
button.disabled=false;button.textContent="Create Login";
}
function openStudentModal(){resetStudentForm();openModal("studentModal")}
function openRoomModal(){editingRoomNumber=null;document.getElementById("roomModalTitle").textContent="Add Room";document.getElementById("roomSaveButton").textContent="Save Room";document.getElementById("rNum").value="";document.getElementById("rCap").value=4;document.getElementById("rFloor").value=1;openModal("roomModal")}
function toast(msg){
let legacyActions={
"Hostel added to frontend demo":["hostels","hostelModal"],"Staff added to frontend demo":["staff","staffModal"],"Payment recorded":["fees","feeModal"],"Complaint submitted":["complaints","complaintModal"],"Notice published":["notices","noticeModal"],"Menu saved":["mess","messModal"],"Committee created":["committees","committeeModal"],"Stock record saved":["stock","stockModal"],"Application submitted":["applications","applicationModal"],"Notification sent":["notifications","notificationModal"]};
let action=legacyActions[msg];if(action&&!window.persistingLegacyAction){window.persistingLegacyAction=true;setTimeout(()=>{saveModalRecord(action[0],action[1]);window.persistingLegacyAction=false},0)}
let recordActions={"Leave approved":"leave","Leave rejected":"leave","Attendance saved":"attendance","Settings saved locally":"settings","Application opened":"activity","Application viewed":"activity"};
let recordModule=recordActions[msg];if(recordModule&&!window.persistingRecordAction){window.persistingRecordAction=true;setTimeout(()=>{saveRecord(recordModule,{action:msg,savedAt:new Date().toISOString()});window.persistingRecordAction=false},0)}
let t=document.getElementById("toast");t.textContent=msg;t.style.display="block";clearTimeout(window.tt);window.tt=setTimeout(()=>t.style.display="none",2500)
}
function save(){
localStorage.setItem("hostel_students",JSON.stringify(students));localStorage.setItem("hostel_rooms",JSON.stringify(rooms));localStorage.setItem("hostel_warnings",JSON.stringify(warnings));
localStorage.setItem("hostel_records",JSON.stringify(records));
fetch(`${apiBase}/sync`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({students,rooms,warnings,records})}).catch(()=>{});
}
function escapeHtml(value){return String(value??"").replace(/[&<>'"]/g,(char)=>({"&":"&amp;","<":"&lt;",">":"&gt;","'":"&#39;","\"":"&quot;"}[char]))}
const emojiIconNames={"📊":"dashboard","👨‍🎓":"users","🛏":"bed","🏢":"building","👮":"key","💰":"wallet","⚠":"alert","📝":"clipboard","🧳":"case","📅":"calendar","📢":"megaphone","🍛":"utensils","🏋️":"dumbbell","📈":"chart","🕒":"clock","👥":"users","🔐":"key","📦":"box","📄":"file","🔔":"bell","⚙️":"settings","🚪":"logout","🏨":"home","✨":"sparkles","☰":"menu","✎":"pencil","📶":"wifi","🔒":"lock","💧":"droplet","🧹":"brush","✅":"check","❌":"x","🚨":"alert"};
const emojiPattern=/\p{Extended_Pictographic}(?:\uFE0F|\u200D\p{Extended_Pictographic}(?:\uFE0F)?)*/gu;
function iconMarkup(name){return `<svg class="ui-icon icon-${name}" aria-hidden="true"><use href="#icon-${name}"></use></svg>`}
function replaceEmojiIcons(root){
if(!root)return;
let walker=document.createTreeWalker(root,NodeFilter.SHOW_TEXT);let textNodes=[];
while(walker.nextNode()){
let node=walker.currentNode;if(node.parentElement?.closest("script,style,svg"))continue;
emojiPattern.lastIndex=0;if(emojiPattern.test(node.nodeValue))textNodes.push(node);
}
for(let node of textNodes){
let text=node.nodeValue;let fragment=document.createDocumentFragment();let cursor=0;emojiPattern.lastIndex=0;
for(let match of text.matchAll(emojiPattern)){
fragment.append(document.createTextNode(text.slice(cursor,match.index)));
let name=emojiIconNames[match[0]]||emojiIconNames[match[0].replace(/[\uFE0F\u200D]/g,"")];
if(name){let svg=document.createElementNS("http://www.w3.org/2000/svg","svg");svg.setAttribute("class",`ui-icon icon-${name}`);svg.setAttribute("aria-hidden","true");let use=document.createElementNS("http://www.w3.org/2000/svg","use");use.setAttribute("href",`#icon-${name}`);svg.append(use);fragment.append(svg)}
else fragment.append(document.createTextNode(match[0]));
cursor=match.index+match[0].length;
}
fragment.append(document.createTextNode(text.slice(cursor)));node.replaceWith(fragment);
}
}
function clearLogoCheckerboard(){
let logos=[...document.querySelectorAll("img.logo-art")];let source=logos[0];if(!source)return;
let removeBackground=()=>{
if(source.dataset.backgroundCleared)return;
try{
let width=source.naturalWidth;let height=source.naturalHeight;if(!width||!height)return;
let canvas=document.createElement("canvas");canvas.width=width;canvas.height=height;
let context=canvas.getContext("2d",{willReadFrequently:true});context.drawImage(source,0,0);
let frame=context.getImageData(0,0,width,height);let pixels=frame.data;let total=width*height;
let visited=new Uint8Array(total);let queue=new Int32Array(total);let head=0;let tail=0;
const isChecker=index=>{let offset=index*4;let red=pixels[offset],green=pixels[offset+1],blue=pixels[offset+2];return red>205&&green>205&&blue>205&&Math.max(red,green,blue)-Math.min(red,green,blue)<20};
const enqueue=index=>{if(!visited[index]&&isChecker(index)){visited[index]=1;queue[tail++]=index}};
for(let x=0;x<width;x++){enqueue(x);enqueue((height-1)*width+x)}
for(let y=1;y<height-1;y++){enqueue(y*width);enqueue(y*width+width-1)}
while(head<tail){let index=queue[head++];let x=index%width;let y=(index/width)|0;pixels[index*4+3]=0;if(x>0)enqueue(index-1);if(x<width-1)enqueue(index+1);if(y>0)enqueue(index-width);if(y<height-1)enqueue(index+width)}
context.putImageData(frame,0,0);let cleanSource=canvas.toDataURL("image/webp",0.92);
if(!cleanSource.startsWith("data:image/webp"))cleanSource=canvas.toDataURL("image/png");
logos.forEach((logo)=>{logo.dataset.backgroundCleared="true";logo.src=cleanSource});
}catch(error){source.dataset.backgroundCleared="failed"}
};
if(source.complete&&source.naturalWidth)removeBackground();else source.addEventListener("load",removeBackground,{once:true});
}
function renderPersistedRecords(){
let pages={hostels:"hostels",staff:"wardens",fees:"fees",complaints:"complaints",leave:"leave",attendance:"attendance",notices:"notices",mess:"mess",committees:"committees",stock:"stock",applications:"applications",notifications:"notifications",settings:"settings",activity:"activity"};
Object.entries(pages).forEach(([module,pageId])=>{
let section=document.getElementById(pageId);if(!section)return;
let saved=records.filter((record)=>record.module===module);let panel=section.querySelector(".backend-records");
if(!saved.length){if(panel)panel.remove();return}
if(!panel){panel=document.createElement("div");panel.className="card backend-records";section.appendChild(panel)}
panel.innerHTML=`<div class="card-head"><h3>Saved from database</h3><span class="badge b-green">${saved.length} record${saved.length===1?"":"s"}</span></div><div class="table-wrap"><table><thead><tr><th>Saved</th><th>Record details</th></tr></thead><tbody>${saved.slice(0,20).map((record)=>`<tr><td>${escapeHtml(new Date(record.createdAt||Date.now()).toLocaleString())}</td><td>${Object.entries(record.payload||{}).map(([key,value])=>`<b>${escapeHtml(key)}:</b> ${escapeHtml(value)} `).join(" · ")}</td></tr>`).join("")}</tbody></table></div>`;
});
}
async function saveRecord(module,payload){
let localRecord={id:`local-${Date.now()}`,module,payload,createdAt:new Date().toISOString()};
records.unshift(localRecord);localStorage.setItem("hostel_records",JSON.stringify(records));renderPersistedRecords();
updateDashboard();
try{
let response=await fetch(`${apiBase}/records`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({module,payload})});
if(response.ok){let result=await response.json();records=records.filter((record)=>record.id!==localRecord.id);records.unshift(result.record);save();renderPersistedRecords();toast(`${module} saved to database`);return true}
}catch(error){}
toast(`${module} saved offline`);return false;
}
function saveModalRecord(module,modalId){
let modal=document.getElementById(modalId);let fields=[...modal.querySelectorAll('input,select,textarea')];
let payload={};fields.forEach((field,index)=>{let key=(field.closest('.form-group')?.querySelector('label')?.textContent||`field_${index}`).trim().toLowerCase().replace(/[^a-z0-9]+(.)/g,(_,char)=>char.toUpperCase());payload[key||`field_${index}`]=field.value});
payload.savedAt=new Date().toISOString();saveRecord(module,payload);closeModal(modalId);
}
function renderStudents(){
let q=(document.getElementById("studentSearch")?.value||"").toLowerCase();
let list=students.filter(s=>(s.name+s.dept+s.room+s.id+s.email).toLowerCase().includes(q));
document.getElementById("studentTable").innerHTML=list.map(s=>{
let account=studentAccounts[s.id];
let accountCell=currentUser?.role!=="admin"?'<span class="badge b-blue">Admin managed</span>':account?account.passwordPending?`<span class="badge b-orange">Password requested</span> <button class="btn primary" onclick="openStudentPasswordModal(${s.id})">Set password</button>`:`<span class="badge ${account.isActive===false?"b-orange":account.mustChangePassword?"b-orange":"b-green"}">${account.isActive===false?"Pending approval / inactive":account.mustChangePassword?`Temporary login: ${escapeHtml(account.username)} · reset required`:`Login: ${escapeHtml(account.username)}`}</span> <button class="btn ${account.isActive===false?"primary":"danger"}" onclick="toggleStudentAccount(${s.id},${account.isActive===false})">${account.isActive===false?"Activate":"Deactivate"}</button>`:`<button class="btn secondary" onclick="openStudentAccountModal(${s.id})">Create login</button>`;
return `<tr><td>#${s.id}</td><td><b>${escapeHtml(s.name)}</b></td><td>${escapeHtml(s.father)}</td><td>${escapeHtml(s.dept)}</td><td>${escapeHtml(s.room)}</td><td>${escapeHtml(s.phone)}</td><td>${escapeHtml(s.email||"")}</td><td><span class="badge ${s.status==="Active"?"b-green":"b-orange"}">${escapeHtml(s.status)}</span></td><td>${accountCell}</td><td><div class="actions"><button class="btn info" onclick="profile(${s.id})">View</button><button class="btn secondary" onclick="editStudent(${s.id})">Edit</button><button class="btn danger" onclick="deleteStudent(${s.id})">Delete</button></div></td></tr>`;
}).join("")||`<tr><td colspan="10" class="empty">No students found.</td></tr>`;
updateDashboard();
}
function profile(id){
let s=students.find(x=>x.id===id);if(!s)return;
let w=warnings.find(x=>x.student===s.name);
document.getElementById("profileContent").innerHTML=`<div class="profile"><div class="big-avatar">${s.name.charAt(0)}</div><div><h2>${s.name}</h2><p style="color:#71807a">Student ID #${s.id}</p><p style="margin-top:10px"><b>Father:</b> ${s.father}<br><b>Department:</b> ${s.dept}<br><b>Room:</b> ${s.room}<br><b>Phone:</b> ${s.phone}</p></div></div><hr style="border:0;border-top:1px solid #e2e8e5;margin:20px 0"><h3>⚠️ Disciplinary Record</h3><p style="margin-top:8px">Applications: <b>${w?.count||0} / 3</b></p>${w?`<div class="warning-card" style="margin-top:12px"><b>Latest: ${w.type}</b><br><small>${w.date}</small><br><br><span class="badge ${w.count>=3?'b-red':'b-orange'}">${w.status}</span></div>`:`<p style="color:#71807a;margin-top:10px">No warning applications.</p>`}`;
openModal("studentProfileModal");
}
function resetStudentForm(){editingStudentId=null;document.getElementById("studentModalTitle").textContent="Add Student";document.getElementById("studentSaveButton").textContent="Save Student";["sName","sFather","sRoom","sPhone","sEmail"].forEach(id=>document.getElementById(id).value="")}
function editStudent(id){let student=students.find((item)=>item.id===id);if(!student)return;editingStudentId=id;document.getElementById("studentModalTitle").textContent="Edit Student";document.getElementById("studentSaveButton").textContent="Update Student";document.getElementById("sName").value=student.name;document.getElementById("sFather").value=student.father;document.getElementById("sDept").value=student.dept;document.getElementById("sRoom").value=student.room;document.getElementById("sPhone").value=student.phone;document.getElementById("sEmail").value=student.email||"";openModal("studentModal")}
async function deleteStudent(id){let student=students.find((item)=>item.id===id);if(!student||!confirm(`Delete ${student.name}?`))return;students=students.filter((item)=>item.id!==id);save();renderStudents();try{await fetch(`${apiBase}/students/${id}`,{method:"DELETE"})}catch(error){}toast("Student deleted")}
async function addStudent(){
let name=document.getElementById("sName").value.trim();if(!name){toast("Enter student name");return}
let email=document.getElementById("sEmail").value.trim().toLowerCase();if(email&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)){toast("Enter a valid student email");return}
if(email&&students.some(student=>String(student.email||"").toLowerCase()===email)){toast("That email is already linked to a student");return}
let student={id:Math.max(1000,...students.map(item=>Number(item.id)||0))+1,name,email,father:document.getElementById("sFather").value||"—",dept:document.getElementById("sDept").value,room:document.getElementById("sRoom").value||"Unassigned",phone:document.getElementById("sPhone").value||"—",status:"Active"};
let button=document.getElementById("studentSaveButton");button.disabled=true;button.textContent="Saving...";
try{
let response=await fetch(`${apiBase}/students/${student.id}`,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify(student)}),result=await response.json();
if(!response.ok)throw new Error(result.message||"Student could not be saved");
students.push(student);save();renderStudents();closeModal("studentModal");toast("Student added successfully");resetStudentForm();
}catch(error){toast(error.message||"Student could not be saved")}
button.disabled=false;button.textContent="Save Student";
}
async function saveStudent(){
if(!editingStudentId){await addStudent();return}
let student=students.find((item)=>item.id===editingStudentId);let name=document.getElementById("sName").value.trim();if(!student||!name){toast("Enter student name");return}
let email=document.getElementById("sEmail").value.trim().toLowerCase();if(email&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)){toast("Enter a valid student email");return}
if(email&&students.some(item=>item.id!==student.id&&String(item.email||"").toLowerCase()===email)){toast("That email is already linked to a student");return}
Object.assign(student,{name,email,father:document.getElementById("sFather").value||"—",dept:document.getElementById("sDept").value,room:document.getElementById("sRoom").value||"Unassigned",phone:document.getElementById("sPhone").value||"—"});
try{let response=await fetch(`${apiBase}/students/${student.id}`,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify(student)});let result=await response.json();if(!response.ok)throw new Error(result.message||"Student could not be updated");save();renderStudents();closeModal("studentModal");resetStudentForm();toast("Student updated")}catch(error){toast(error.message)}
}
function renderRooms(){
document.getElementById("roomGrid").innerHTML=rooms.map(r=>{let pct=Math.round(r[2]/r[1]*100);return `<div class="room"><strong>Room ${r[0]}</strong><p>${r[2]} / ${r[1]} beds occupied</p><div class="progress"><span style="width:${pct}%"></span></div><div style="margin-top:10px"><span class="badge ${pct>=100?'b-red':'b-green'}">${pct>=100?'FULL':(r[1]-r[2])+' bed available'}</span></div><div class="actions room-actions"><button class="btn secondary" onclick="editRoom('${r[0]}')">Edit</button><button class="btn danger" onclick="deleteRoom('${r[0]}')">Delete</button></div></div>`}).join("")||'<div class="empty">No rooms found.</div>';
updateDashboard();
}
function editRoom(number){let room=rooms.find((item)=>item[0]===number);if(!room)return;editingRoomNumber=number;document.getElementById("roomModalTitle").textContent="Edit Room";document.getElementById("roomSaveButton").textContent="Update Room";document.getElementById("rNum").value=room[0];document.getElementById("rCap").value=room[1];document.getElementById("rFloor").value=room[3]||1;openModal("roomModal")}
async function deleteRoom(number){if(!confirm(`Delete room ${number}?`))return;rooms=rooms.filter((room)=>room[0]!==number);save();renderRooms();try{await fetch(`${apiBase}/rooms/${encodeURIComponent(number)}`,{method:"DELETE"})}catch(error){}toast("Room deleted")}
function addRoom(){
let n=document.getElementById("rNum").value.trim();if(!n){toast("Enter room number");return}rooms.push([n,+document.getElementById("rCap").value||4,0]);save();renderRooms();closeModal("roomModal");toast("Room added");
}
async function saveRoom(){
if(!editingRoomNumber){addRoom();return}
let oldNumber=editingRoomNumber;let room=rooms.find((item)=>item[0]===oldNumber);let number=document.getElementById("rNum").value.trim();let capacity=+document.getElementById("rCap").value||4;if(!room||!number){toast("Enter room number");return}room[0]=number;room[1]=capacity;room[3]=+document.getElementById("rFloor").value||1;if(room[2]>capacity)room[2]=capacity;save();renderRooms();closeModal("roomModal");editingRoomNumber=null;document.getElementById("roomModalTitle").textContent="Add Room";document.getElementById("roomSaveButton").textContent="Save Room";toast("Room updated");try{await fetch(`${apiBase}/rooms/${encodeURIComponent(oldNumber)}`,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({roomNumber:number,capacity,occupiedBeds:room[2],floor:room[3]})})}catch(error){}
}
function renderAttendance(){
let table=document.getElementById("attendanceTable");if(!table)return;
table.innerHTML=students.map((student)=>{let status=attendance[student.id]||"Present";return `<tr><td><b>${student.name}</b></td><td>${student.room}</td><td>${student.dept}</td><td><div class="attendance-controls"><button class="btn ${status==="Present"?"primary":"secondary"}" onclick="setAttendance(${student.id},'Present')">Present</button><button class="btn ${status==="Absent"?"danger":"secondary"}" onclick="setAttendance(${student.id},'Absent')">Absent</button></div></td></tr>`}).join("")||`<tr><td colspan="4" class="empty">No students found.</td></tr>`;
let present=students.filter((student)=>(attendance[student.id]||"Present")==="Present").length;let absent=students.length-present;document.getElementById("presentCount").textContent=present;document.getElementById("absentCount").textContent=absent;document.getElementById("attendanceRate").textContent=`${students.length?Math.round(present/students.length*100):0}%`;
}
function renderMonthlyAttendance(){
let table=document.getElementById("monthlyAttendanceTable");let picker=document.getElementById("attendanceMonth");if(!table||!picker)return;
if(!picker.value)picker.value=new Date().toISOString().slice(0,7);
let month=picker.value;let marked=new Map();
records.filter((record)=>record.module==="attendance"&&record.payload?.date?.slice(0,7)===month).forEach((record)=>{
Object.entries(record.payload.entries||{}).forEach(([studentId,status])=>{marked.set(`${record.payload.date}-${studentId}`,status)})
});
let summary=students.map((student)=>{let entries=[...marked.entries()].filter(([key])=>key.endsWith(`-${student.id}`)).map(([,status])=>status);let present=entries.filter((status)=>status==="Present").length;let absent=entries.filter((status)=>status==="Absent").length;let total=present+absent;return {...student,present,absent,total,rate:total?Math.round(present/total*100):0}});
table.innerHTML=summary.map((student)=>`<tr><td><b>${student.name}</b><br><small style="color:var(--muted)">#${student.id}</small></td><td>${student.room}</td><td>${student.total}</td><td><span class="badge b-green">${student.present}</span></td><td><span class="badge b-red">${student.absent}</span></td><td><b>${student.rate}%</b><div class="progress" style="margin-top:6px"><span style="width:${student.rate}%"></span></div></td></tr>`).join("")||`<tr><td colspan="6" class="empty">No students found.</td></tr>`;
}
function setAttendance(id,status){attendance[id]=status;localStorage.setItem("hostel_attendance",JSON.stringify(attendance));renderAttendance()}
function saveAttendance(){saveRecord("attendance",{date:new Date().toISOString().slice(0,10),entries:{...attendance}});renderMonthlyAttendance();toast("Attendance saved")}
function issueWarning(){
let student=document.getElementById("wStudent").value.trim();if(!student){toast("Enter student name");return}
let old=warnings.find(w=>w.student.toLowerCase()===student.toLowerCase());
let count=(old?.count||0)+1;
let type=document.getElementById("wType").value;
let status=count>=3?"Stuck-Off Notice":"Warning";
if(old){old.count=count;old.type=type;old.date=new Date().toLocaleDateString("en-GB",{day:"2-digit",month:"short",year:"numeric"});old.status=status}
else warnings.push({student,room:document.getElementById("wRoom").value||"—",count,type,date:new Date().toLocaleDateString("en-GB",{day:"2-digit",month:"short",year:"numeric"}),status});
save();renderWarnings();closeModal("warningModal");
if(count>=3)toast("3rd application reached — Stuck-Off Notice workflow triggered");else toast("Warning application issued");
}
function renderWarnings(){
document.getElementById("warningTable").innerHTML=warnings.map((w,i)=>`<tr><td><b>${w.student}</b></td><td>${w.room}</td><td><b>${w.count} / 3</b><div class="warnbar"><span style="width:${Math.min(w.count,3)/3*100}%"></span></div></td><td>${w.type}</td><td>${w.date}</td><td><span class="badge ${w.count>=3?'b-red':'b-orange'}">${w.status}</span></td><td>${w.count>=3?`<button class="btn danger" onclick="notice(${i})">View Notice</button>`:`<button class="btn warning" onclick="profileWarning(${i})">View</button>`}</td></tr>`).join("");
document.getElementById("activeWarnings").textContent=warnings.filter(w=>w.count<3).length;
document.getElementById("stuckCount").textContent=warnings.filter(w=>w.count>=3).length;
updateDashboard();
}
function profileWarning(i){let w=warnings[i];toast(`${w.student}: ${w.count}/3 applications — ${w.type}`)}
function notice(i){let w=warnings[i];document.getElementById("profileContent").innerHTML=`<div style="text-align:center"><div style="font-size:45px">🚨</div><h2>STUCK-OFF NOTICE</h2><p style="color:#71807a;margin:8px 0 20px">Disciplinary Record</p></div><div class="card" style="background:#fafcfb"><p><b>Student:</b> ${w.student}</p><p style="margin-top:8px"><b>Room:</b> ${w.room}</p><p style="margin-top:8px"><b>Total Applications:</b> ${w.count}</p><p style="margin-top:8px"><b>Latest Violation:</b> ${w.type}</p><p style="margin-top:8px"><b>Date:</b> ${w.date}</p></div><p style="font-size:12px;color:#71807a">This frontend demo flags the student after the configured third application. Formal issuance should follow the institution's actual disciplinary rules and authorization process.</p><div class="modal-actions"><button class="btn secondary" onclick="closeModal('studentProfileModal')">Close</button><button class="btn primary" onclick="toast('Print function can be connected to backend/PDF')">Print Notice</button></div>`;openModal("studentProfileModal")}
function updateDashboard(){
let occupiedRooms=rooms.filter((room)=>Number(room[2])>0).length;
let availableBeds=rooms.reduce((total,room)=>total+Math.max(0,Number(room[1])-Number(room[2])),0);
let pendingRequests=records.filter((record)=>["leave","applications"].includes(record.module)&&!/(approved|rejected|completed)/i.test(String(record.payload?.status||"Pending"))).length;
let openComplaints=records.filter((record)=>record.module==="complaints"&&!/(resolved|closed)/i.test(String(record.payload?.status||"Open"))).length;
[["studentCount",students.length],["roomCount",rooms.length],["occupiedRoomCount",occupiedRooms],["availableBedCount",availableBeds],["pendingRequestCount",pendingRequests],["openComplaintCount",openComplaints]].forEach(([id,value])=>{let element=document.getElementById(id);if(element)element.textContent=value});
let now=new Date();let hour=now.getHours();let greeting=hour<12?"Good morning":hour<18?"Good afternoon":"Good evening";
let dateElement=document.getElementById("dashboardDate");let greetingElement=document.getElementById("greetingTitle");
if(dateElement)dateElement.textContent=now.toLocaleDateString(undefined,{weekday:"long",year:"numeric",month:"long",day:"numeric"});
if(greetingElement)greetingElement.textContent=`${greeting}, ${currentUser?.full_name||"Hostel team"}`;
let studentPanel=document.getElementById("dashStudents");
if(studentPanel)studentPanel.innerHTML=students.slice(0,4).map((student)=>`<tr><td><b>${escapeHtml(student.name)}</b></td><td>${escapeHtml(student.room)}</td><td>${escapeHtml(student.dept)}</td><td><span class="badge b-green">${escapeHtml(student.status||"Active")}</span></td></tr>`).join("")||'<tr><td colspan="4" class="empty">No students have been added yet.</td></tr>';
let activityPanel=document.getElementById("dashboardActivity");
if(activityPanel){
let items=records.slice(0,5).map((record)=>({title:record.payload?.action||record.payload?.title||record.payload?.subject||`${moduleLabels[record.module]||record.module} record saved`,detail:`${moduleLabels[record.module]||record.module} · ${new Date(record.createdAt||Date.now()).toLocaleString()}`}));
if(!items.length)items=warnings.slice(0,5).map((warning)=>({title:`Warning application · ${warning.student}`,detail:`${warning.type} · ${warning.date}`}));
activityPanel.innerHTML=items.map((item)=>`<div class="event"><b>${escapeHtml(item.title)}</b><p>${escapeHtml(item.detail)}</p></div>`).join("")||'<p class="empty">No recent activity recorded yet.</p>';
}
let activeWarnings=warnings.filter((warning)=>!/(resolved|closed)/i.test(String(warning.status||"")));
let activeWarningElement=document.getElementById("activeWarnings");if(activeWarningElement)activeWarningElement.textContent=activeWarnings.length;
let warningCountElement=document.getElementById("warningCount");if(warningCountElement)warningCountElement.textContent=activeWarnings.length;
let stuckCountElement=document.getElementById("stuckCount");if(stuckCountElement)stuckCountElement.textContent=warnings.filter((warning)=>/stuck/i.test(warning.status||"")).length;
}
function renderAll(){renderStudents();renderRooms();renderWarnings();renderAttendance();renderMonthlyAttendance();renderPersistedRecords();applyRoleAccess();updateDashboard()}
document.addEventListener("keydown",e=>{if(e.key==="Escape")document.querySelectorAll(".modal.show").forEach(m=>m.classList.remove("show"))});
replaceEmojiIcons(document.body);
clearLogoCheckerboard();
checkHostelServer();
window.setInterval(checkHostelServer,15000);
window.setInterval(()=>{if(currentUser?.role==="admin")loadStudentAccounts()},30000);
window.addEventListener("online",checkHostelServer);
window.addEventListener("offline",checkHostelServer);
const studentLoginSession=sessionStorage.getItem("hostel_student_login");
if(studentLoginSession){
sessionStorage.removeItem("hostel_student_login");
try{
let session=JSON.parse(studentLoginSession);
if(session.user?.role!=="student"||typeof session.token!=="string")throw new Error("Student login session is invalid");
completeLogin(session);
}catch(error){showLoginError(error.message||"Student login could not be completed")}
}
