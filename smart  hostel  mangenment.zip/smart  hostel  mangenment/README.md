# Smart Hostel Management System

This workspace contains the frontend prototype plus a real SQLite-backed API.

## Run the application

1. Install Node.js 18 or newer.
2. In this folder run:

```bash
npm install
npm start
```

3. Open `http://localhost:3000` and sign in with an active account.

The application and SQLite database run locally; internet access is not required for normal use. Keep the server computer running while users are signed in. The UI checks the local server and shows its availability.

To allow other devices on the same local network to use the system, the server listens on all network interfaces by default. Find the server computer's local IPv4 address (for example, with `ipconfig` on Windows) and open `http://<server-ip>:3000` on the other devices. Allow Node.js or TCP port 3000 through the server computer's private-network firewall when prompted. Do not expose the server directly to the public internet without configuring a secure deployment.

`HOST` and `PORT` can be set in `.env` to change the listening interface and port. Leave `HOST` unset (or set it to `0.0.0.0`) for local-network access; set it to `127.0.0.1` to restrict access to the server computer.

The server reads configuration from `.env`, creates `database/hostel.sqlite` automatically, applies `database/schema.sql`, and loads `database/seed.sql` on startup. Set `HOSTEL_DATABASE_PATH` in `.env` to change the SQLite file; relative paths are resolved from the project folder and absolute paths are also supported. Keep the database file backed up to preserve saved data.

For example:

```env
HOSTEL_DATABASE_PATH=database/hostel.sqlite
```

The SQL files use SQLite syntax and are not directly importable into MySQL Workbench.

## Student accounts

Students can request a login from `http://localhost:3000/student-portal-login.html` by submitting their full name, department, and room number. The request appears in the administrator's **Mailbox**. The administrator sets a password and gives the student their login ID and password; the student can sign in with those credentials without a forced password-update screen. Administrators can deactivate the account later. Passwords require at least 8 characters with uppercase, lowercase, and a number.

The student portal includes hostel occupancy and attendance reports, room availability, the student's own fees/utilities, news/notices, and the mess menu. Students can also submit applications and view their own request statuses. Students cannot open staff modules or view another student's private records.

## API surface

- `GET /api/health` - service health check
- `POST /api/auth/login` - authenticate an active account
- `POST /api/auth/student/signup` - create an inactive student account pending administrator approval
- `POST /api/auth/student/password-request` - request a temporary student login password
- `POST /api/auth/student/register` - create a student login for an existing student record
- `GET /api/student-accounts` and `PATCH /api/student-accounts/:studentId/status` - administrator student-account management and mailbox requests
- `PATCH /api/student-accounts/:studentId/password` - set a password and activate a requested student login
- `GET /api/student/portal` - authenticated, student-scoped portal data
- `GET /api/state` - students, rooms, and warnings for the dashboard
- `GET /api/records/:module` - saved records for a hostel module
- `POST /api/records` - persist a module record as JSON
- `POST /api/sync` - synchronizes the current frontend state to SQLite
- `PUT /api/students/:id` - upserts one student record

The frontend is connected to these endpoints. Student, room, and warning changes use the existing structured tables; forms and workflow actions for fees, complaints, notices, leave, attendance, mess, stock, applications, notifications, staff, committees, roles, hostels, settings, and activity are stored in the `app_records` table.

The standalone HTML can be opened directly for a browser-only demo, but authenticated student/admin features and shared persistent data require the local API server. Running the local server works without internet access; multiple devices can share the same SQLite-backed data over the local network.

## Production notes

Before deployment, require strong passwords, add session/JWT authentication, move secrets to environment variables, and add role-based authorization to each write endpoint.
