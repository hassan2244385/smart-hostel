function setPasswordVisibility(input, button){
const visible=input.type==="password";
input.type=visible?"text":"password";
button.textContent=visible?"Hide":"Show";
button.setAttribute("aria-label",`${visible?"Hide":"Show"} password`);
button.setAttribute("aria-pressed",String(visible));
}

document.querySelectorAll('input[type="password"]').forEach((input,index)=>{
if(!input.id)input.id=`passwordField${index+1}`;
const existingToggle=input.parentElement.querySelector('.password-toggle[aria-controls="'+input.id+'"]');
if(existingToggle)return;
const wrapper=document.createElement("div");
wrapper.className="password-field-wrap";
input.before(wrapper);
wrapper.append(input);
const button=document.createElement("button");
button.type="button";
button.className="password-toggle";
button.textContent="Show";
button.setAttribute("aria-label","Show password");
button.setAttribute("aria-controls",input.id);
button.setAttribute("aria-pressed","false");
button.addEventListener("click",()=>setPasswordVisibility(input,button));
wrapper.append(button);
});

document.addEventListener("keydown",event=>{
if(event.key!=="Enter"||event.defaultPrevented||event.target?.tagName!=="INPUT")return;
if(["button","checkbox","radio","submit","reset","file"].includes(event.target.type))return;
const form=event.target.form;
if(form){
event.preventDefault();
form.requestSubmit();
return;
}
const modal=event.target.closest(".modal.show");
const action=modal?.querySelector(".modal-actions .btn.primary, .modal-box > .btn.primary");
if(action){
event.preventDefault();
action.click();
}
});
